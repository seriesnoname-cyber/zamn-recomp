// Interpreter-only build: no recompiled blocks.
#include "cpu.h"
int recomp_dispatch(Cpu* cpu) { (void) cpu; return 0; }

const int recomp_blockCount = 0, recomp_insnCount = 0;
