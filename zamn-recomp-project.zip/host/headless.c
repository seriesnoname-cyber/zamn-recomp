// Headless runner (reference interpreter or recompiled build) with scripted input.
#include <stdio.h>
#include <stdlib.h>
#include "snes.h"
extern FILE* verifyOut;
extern int traceN;
extern uint64_t recomp_stat_hit, recomp_stat_miss;
extern const int recomp_blockCount, recomp_insnCount;
int main(int argc, char** argv) {
  if (argc < 4) { fprintf(stderr, "uso: %s rom frames out.ppm [verify.log]\n", argv[0]); return 1; }
  FILE* f = fopen(argv[1], "rb"); if (!f) return 1;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  uint8_t* rom = malloc(n); if (fread(rom, 1, n, f) != (size_t) n) return 1; fclose(f);
  if (argc > 4) verifyOut = fopen(argv[4], "w");
  if (getenv("RECOMP_TRACE_N")) traceN = atoi(getenv("RECOMP_TRACE_N"));
  Snes* s = snes_init();
  if (!snes_loadRom(s, rom, (int) n)) { fprintf(stderr, "ROM invalida\n"); return 2; }
  snes_reset(s, true);
  int frames = atoi(argv[2]);
  uint64_t seed = getenv("INPUT_SEED") ? strtoull(getenv("INPUT_SEED"), 0, 10) * 2654435761ull + 88172645463325252ull : 0;
  uint16_t mask = 0;
  static int16_t audio[2048 * 2];
  for (int i = 0; i < frames; i++) {
    // scripted input: mash Start / A / directions so we walk through menus and into gameplay
    int ph = (i / 8) % 2;
    snes_setButtonState(s, 1, 3, i > 200 && ph);              // start
    snes_setButtonState(s, 1, 8, i > 200 && !ph);             // A
    snes_setButtonState(s, 1, 0, i > 600 && ((i / 30) % 3 == 0)); // B (shoot)
    snes_setButtonState(s, 1, 7, i > 600 && ((i / 60) % 4 == 0)); // right
    snes_setButtonState(s, 1, 5, i > 600 && ((i / 90) % 4 == 1)); // down
    snes_setButtonState(s, 1, 6, i > 600 && ((i / 75) % 4 == 2)); // left
    snes_setButtonState(s, 1, 4, i > 600 && ((i / 45) % 4 == 3)); // up
    if (seed && i > 2000) {   // randomized play: new button mask every few frames
      if (i % 6 == 0) { seed ^= seed << 13; seed ^= seed >> 7; seed ^= seed << 17; mask = (uint16_t) (seed >> 8); }
      for (int b = 0; b < 12; b++) snes_setButtonState(s, 1, b, (mask >> b) & 1);
    }
    snes_runFrame(s);
    snes_setSamples(s, audio, 534);
  }
  static uint8_t px[512 * 4 * 480];
  snes_setPixelFormat(s, pixelFormatRGBX);
  snes_setPixels(s, px);
  FILE* o = fopen(argv[3], "wb");
  fprintf(o, "P6\n256 224\n255\n");
  for (int y = 0; y < 224; y++) for (int x = 0; x < 256; x++) {
    uint8_t* p = &px[(y * 2 * 512 + x * 2) * 4];
    fputc(p[0], o); fputc(p[1], o); fputc(p[2], o);
  }
  fclose(o);
  uint64_t ramsum = 1469598103934665603ull;
  for (int i = 0; i < 0x20000; i++) { ramsum ^= s->ram[i]; ramsum *= 1099511628211ull; }
  printf("frames=%u pc=%02x:%04x wram_hash=%016llx\n", s->frames, s->cpu->k, s->cpu->pc, (unsigned long long) ramsum);
#ifdef RECOMP
  printf("recomp: %d blocks / %d insns; block hits=%llu interpreter fallbacks=%llu\n",
         recomp_blockCount, recomp_insnCount, (unsigned long long) recomp_stat_hit, (unsigned long long) recomp_stat_miss);
#endif
  if (verifyOut) fclose(verifyOut);
  return 0;
}
