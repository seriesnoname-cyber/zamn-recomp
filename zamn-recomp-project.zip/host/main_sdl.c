// SDL2 front end: desktop (testing) and Android (touch controls + gamepads).
// Video/audio/input glue around the recompiled game core.
//
// usage (desktop):  zamn rom.sfc [--frames N] [--shot out.ppm] [--touch]
// Android: the ROM path is <internal storage>/rom.sfc (copied there by LauncherActivity).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <SDL.h>
#include "snes.h"

extern uint64_t recomp_stat_hit, recomp_stat_miss;

#define MAX_FINGERS 10
// SNES pad bit order used by snes_setButtonState
enum { B_B = 0, B_Y, B_SELECT, B_START, B_UP, B_DOWN, B_LEFT, B_RIGHT, B_A, B_X, B_L, B_R };

typedef struct { float x, y, w, h; int btn; const char* label; } Pad;   // normalised screen coords
typedef struct { bool down; float x, y; } Finger;

static Snes* snes;
static SDL_Window* window;
static SDL_Renderer* renderer;
static SDL_Texture* texture;
static SDL_AudioDeviceID audioDev;
static int16_t* audioBuf;
static const int AUDIO_HZ = 48000;
static int wantedSamples = 800;
static Finger fingers[MAX_FINGERS];
static SDL_FingerID fingerIds[MAX_FINGERS];
static bool showTouch = false;
static uint16_t keyMask = 0, padMask = 0, touchMask = 0, lastMask = 0;

static uint8_t* readFile(const char* path, int* len) {
  FILE* f = fopen(path, "rb");
  if (!f) return NULL;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  uint8_t* d = malloc(n);
  if (!d || fread(d, 1, n, f) != (size_t) n) { fclose(f); free(d); return NULL; }
  fclose(f);
  *len = (int) n;
  return d;
}

// ---- touch layout (landscape) ---------------------------------------------------
static Pad pads[] = {
  // d-pad (handled separately as a joystick-like region), drawn as 4 arms
  { 0.05f, 0.52f, 0.07f, 0.14f, B_LEFT,  "<" },
  { 0.19f, 0.52f, 0.07f, 0.14f, B_RIGHT, ">" },
  { 0.12f, 0.38f, 0.07f, 0.14f, B_UP,    "^" },
  { 0.12f, 0.66f, 0.07f, 0.14f, B_DOWN,  "v" },
  // face buttons
  { 0.84f, 0.52f, 0.075f, 0.14f, B_Y, "Y" },
  { 0.93f, 0.40f, 0.075f, 0.14f, B_A, "A" },   // right
  { 0.84f, 0.66f, 0.075f, 0.14f, B_B, "B" },   // bottom
  { 0.75f, 0.40f, 0.075f, 0.14f, B_X, "X" },   // top-left of the diamond... (see draw)
  // meta + shoulders
  { 0.38f, 0.84f, 0.09f, 0.10f, B_SELECT, "SEL" },
  { 0.53f, 0.84f, 0.09f, 0.10f, B_START,  "START" },
  { 0.02f, 0.04f, 0.16f, 0.14f, B_L, "L" },
  { 0.82f, 0.04f, 0.16f, 0.14f, B_R, "R" },
};
#define NPADS ((int) (sizeof(pads) / sizeof(pads[0])))

static void layoutFace(void) {
  // diamond: X top, Y left, A right, B bottom
  pads[4] = (Pad){ 0.78f, 0.55f, 0.075f, 0.14f, B_Y, "Y" };
  pads[5] = (Pad){ 0.92f, 0.55f, 0.075f, 0.14f, B_A, "A" };
  pads[6] = (Pad){ 0.85f, 0.70f, 0.075f, 0.14f, B_B, "B" };
  pads[7] = (Pad){ 0.85f, 0.40f, 0.075f, 0.14f, B_X, "X" };
}

static uint16_t computeTouchMask(int w, int h) {
  uint16_t m = 0;
  for (int f = 0; f < MAX_FINGERS; f++) {
    if (!fingers[f].down) continue;
    float fx = fingers[f].x, fy = fingers[f].y;
    for (int i = 0; i < NPADS; i++) {
      // generous hit boxes (+40%) so thumbs sliding between buttons keep working
      float mx = pads[i].w * 0.2f, my = pads[i].h * 0.2f;
      if (fx >= pads[i].x - mx && fx <= pads[i].x + pads[i].w + mx &&
          fy >= pads[i].y - my && fy <= pads[i].y + pads[i].h + my)
        m |= 1 << pads[i].btn;
    }
  }
  (void) w; (void) h;
  return m;
}

static void drawTouch(int w, int h) {
  SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
  for (int i = 0; i < NPADS; i++) {
    bool on = (touchMask >> pads[i].btn) & 1;
    SDL_Rect r = { (int) (pads[i].x * w), (int) (pads[i].y * h), (int) (pads[i].w * w), (int) (pads[i].h * h) };
    SDL_SetRenderDrawColor(renderer, on ? 255 : 200, on ? 255 : 200, on ? 255 : 200, on ? 150 : 60);
    SDL_RenderFillRect(renderer, &r);
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 110);
    SDL_RenderDrawRect(renderer, &r);
  }
}

// ---- helpers -----------------------------------------------------------------------
static void applyInput(void) {
  uint16_t m = keyMask | padMask | touchMask;
  if (m == lastMask) return;
  for (int b = 0; b < 12; b++) snes_setButtonState(snes, 1, b, (m >> b) & 1);
  lastMask = m;
}

static int keyToButton(SDL_Keycode k) {
  switch (k) {
    case SDLK_z: return B_B;     case SDLK_a: return B_Y;
    case SDLK_RSHIFT: return B_SELECT; case SDLK_RETURN: return B_START;
    case SDLK_UP: return B_UP;   case SDLK_DOWN: return B_DOWN;
    case SDLK_LEFT: return B_LEFT; case SDLK_RIGHT: return B_RIGHT;
    case SDLK_x: return B_A;     case SDLK_s: return B_X;
    case SDLK_d: return B_L;     case SDLK_c: return B_R;
  }
  return -1;
}

static int padToButton(Uint8 b) {
  switch (b) {
    case SDL_CONTROLLER_BUTTON_A: return B_B;      // south = B (SNES layout)
    case SDL_CONTROLLER_BUTTON_B: return B_A;
    case SDL_CONTROLLER_BUTTON_X: return B_Y;
    case SDL_CONTROLLER_BUTTON_Y: return B_X;
    case SDL_CONTROLLER_BUTTON_BACK: return B_SELECT;
    case SDL_CONTROLLER_BUTTON_START: return B_START;
    case SDL_CONTROLLER_BUTTON_DPAD_UP: return B_UP;
    case SDL_CONTROLLER_BUTTON_DPAD_DOWN: return B_DOWN;
    case SDL_CONTROLLER_BUTTON_DPAD_LEFT: return B_LEFT;
    case SDL_CONTROLLER_BUTTON_DPAD_RIGHT: return B_RIGHT;
    case SDL_CONTROLLER_BUTTON_LEFTSHOULDER: return B_L;
    case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER: return B_R;
  }
  return -1;
}

static void saveShot(const char* path) {
  static uint8_t px[512 * 4 * 480];
  snes_setPixelFormat(snes, pixelFormatRGBX);
  snes_setPixels(snes, px);
  FILE* o = fopen(path, "wb");
  if (!o) return;
  fprintf(o, "P6\n256 224\n255\n");
  for (int y = 0; y < 224; y++) for (int x = 0; x < 256; x++) {
    uint8_t* p = &px[(y * 2 * 512 + x * 2) * 4];
    fputc(p[0], o); fputc(p[1], o); fputc(p[2], o);
  }
  fclose(o);
}

int main(int argc, char** argv) {
  const char* romPath = NULL; const char* shot = NULL; int testFrames = 0;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--frames") && i + 1 < argc) testFrames = atoi(argv[++i]);
    else if (!strcmp(argv[i], "--shot") && i + 1 < argc) shot = argv[++i];
    else if (!strcmp(argv[i], "--touch")) showTouch = true;
    else romPath = argv[i];
  }
  char androidRom[1024];
#ifdef __ANDROID__
  showTouch = true;
  snprintf(androidRom, sizeof androidRom, "%s/rom.sfc", SDL_AndroidGetInternalStoragePath());
  romPath = androidRom;
#else
  (void) androidRom;
#endif
  if (!romPath) { fprintf(stderr, "uso: %s rom.sfc [--frames N] [--shot out.ppm] [--touch]\n", argv[0]); return 1; }

  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER) != 0) {
    SDL_Log("SDL_Init: %s", SDL_GetError()); return 1;
  }
  SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");          // sharp pixels
  SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "0");
  window = SDL_CreateWindow("ZAMN", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1024, 768,
                            SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN | SDL_WINDOW_ALLOW_HIGHDPI | SDL_WINDOW_FULLSCREEN_DESKTOP * (showTouch ? 1 : 0));
  renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (!renderer) renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
  if (!renderer) { SDL_Log("renderer: %s", SDL_GetError()); return 1; }
  texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBX8888, SDL_TEXTUREACCESS_STREAMING, 512, 480);

  int romLen = 0;
  uint8_t* rom = readFile(romPath, &romLen);
  snes = snes_init();
  if (!rom || !snes_loadRom(snes, rom, romLen)) {
    SDL_Log("ROM invalida ou ausente: %s", romPath);
    return 2;
  }
  free(rom);
  snes_setPixelFormat(snes, pixelFormatRGBX);
  snes_reset(snes, true);
  layoutFace();

  SDL_AudioSpec want, have;
  SDL_zero(want); want.freq = AUDIO_HZ; want.format = AUDIO_S16; want.channels = 2; want.samples = 1024; want.callback = NULL;
  audioDev = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);
  audioBuf = malloc(AUDIO_HZ / 50 * 4);
  if (audioDev) SDL_PauseAudioDevice(audioDev, 0);
  wantedSamples = AUDIO_HZ / 60;
  double wantedFrame = 1.0 / 60.0, acc = 0;
  uint64_t freq = SDL_GetPerformanceFrequency(), last = SDL_GetPerformanceCounter();

  bool running = true, paused = false;
  int frames = 0;
  while (running) {
    SDL_Event e;
    while (SDL_PollEvent(&e)) {
      switch (e.type) {
        case SDL_QUIT: running = false; break;
        case SDL_KEYDOWN: case SDL_KEYUP: {
          if (e.key.repeat) break;
          if (e.type == SDL_KEYDOWN && (e.key.keysym.sym == SDLK_ESCAPE || e.key.keysym.sym == SDLK_AC_BACK)) { running = false; break; }
          int b = keyToButton(e.key.keysym.sym);
          if (b >= 0) { if (e.type == SDL_KEYDOWN) keyMask |= 1 << b; else keyMask &= ~(1 << b); }
          break;
        }
        case SDL_CONTROLLERDEVICEADDED: SDL_GameControllerOpen(e.cdevice.which); break;
        case SDL_CONTROLLERBUTTONDOWN: case SDL_CONTROLLERBUTTONUP: {
          int b = padToButton(e.cbutton.button);
          if (b >= 0) { if (e.type == SDL_CONTROLLERBUTTONDOWN) padMask |= 1 << b; else padMask &= ~(1 << b); }
          break;
        }
        case SDL_FINGERDOWN: case SDL_FINGERMOTION: case SDL_FINGERUP: {
          int slot = -1;
          for (int i = 0; i < MAX_FINGERS; i++) if (fingers[i].down && fingerIds[i] == e.tfinger.fingerId) slot = i;
          if (slot < 0 && e.type != SDL_FINGERUP) for (int i = 0; i < MAX_FINGERS; i++) if (!fingers[i].down) { slot = i; break; }
          if (slot >= 0) {
            fingerIds[slot] = e.tfinger.fingerId;
            fingers[slot].down = e.type != SDL_FINGERUP;
            fingers[slot].x = e.tfinger.x; fingers[slot].y = e.tfinger.y;
          }
          break;
        }
        case SDL_APP_WILLENTERBACKGROUND: paused = true; if (audioDev) SDL_PauseAudioDevice(audioDev, 1); break;
        case SDL_APP_DIDENTERFOREGROUND:  paused = false; last = SDL_GetPerformanceCounter(); if (audioDev) SDL_PauseAudioDevice(audioDev, 0); break;
      }
    }
    int w, h; SDL_GetRendererOutputSize(renderer, &w, &h);
    touchMask = showTouch ? computeTouchMask(w, h) : 0;
    applyInput();

    uint64_t now = SDL_GetPerformanceCounter();
    acc += (now - last) / (double) freq; last = now;
    if (acc > 0.25) acc = 0.25;                       // don't spiral after a stall
    if (testFrames) acc = wantedFrame;                // headless test: run as fast as possible
    while (!paused && acc >= wantedFrame - 0.002) {
      acc -= wantedFrame;
      snes_runFrame(snes);
      snes_setSamples(snes, audioBuf, wantedSamples);
      if (audioDev && SDL_GetQueuedAudioSize(audioDev) <= (Uint32) wantedSamples * 4 * 6)
        SDL_QueueAudio(audioDev, audioBuf, wantedSamples * 4);
      void* pixels; int pitch;
      if (SDL_LockTexture(texture, NULL, &pixels, &pitch) == 0) {
        snes_setPixels(snes, (uint8_t*) pixels);
        SDL_UnlockTexture(texture);
      }
      frames++;
      if (testFrames && frames >= testFrames) running = false;
    }

    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    // keep 4:3 (the SNES' 8:7 pixels), letterboxed; shift up a little on phones so thumbs have room
    SDL_Rect src = { 0, 0, 512, 448 };
    int dw = w, dh = w * 3 / 4;
    if (dh > h) { dh = h; dw = h * 4 / 3; }
    SDL_Rect dst = { (w - dw) / 2, showTouch ? 0 : (h - dh) / 2, dw, dh };
    SDL_RenderCopy(renderer, texture, &src, &dst);
    if (showTouch) drawTouch(w, h);
    SDL_RenderPresent(renderer);
  }
  if (shot) saveShot(shot);
  if (testFrames) printf("frames=%d recompiled-block-hits=%llu interpreter-fallbacks=%llu\n", frames,
                         (unsigned long long) recomp_stat_hit, (unsigned long long) recomp_stat_miss);
  if (audioDev) SDL_CloseAudioDevice(audioDev);
  SDL_DestroyRenderer(renderer); SDL_DestroyWindow(window); SDL_Quit();
  return 0;
}
