// Runtime support for the recompiled CPU: miss logging (coverage feedback)
// and the lockstep verification hook.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "snes.h"

// ---- miss log: unique (pb:pc, m, x) that had no recompiled block ---------------
#define MISS_CAP (1u << 16)
static uint32_t missKeys[MISS_CAP];
static uint8_t  missUsed[MISS_CAP];
static int missCount = 0;
static int atexitSet = 0;

static void dumpMisses(void) {
  const char* path = getenv("RECOMP_COVERAGE");
  if (!path) return;
  FILE* f = fopen(path, "w");
  if (!f) return;
  for (uint32_t i = 0; i < MISS_CAP; i++)
    if (missUsed[i]) {
      uint32_t k = missKeys[i];
      fprintf(f, "%02x:%04x %d %d\n", (k >> 18) & 0xff, (k >> 2) & 0xffff, (k >> 1) & 1, k & 1);
    }
  fclose(f);
}

void recomp_logMiss(Cpu* cpu) {
  if (!atexitSet) { atexitSet = 1; atexit(dumpMisses); }
  uint32_t k = ((((uint32_t) cpu->k << 16) | cpu->pc) << 2) | ((uint32_t) cpu->mf << 1) | (uint32_t) cpu->xf;
  uint32_t h = (k * 2654435761u) & (MISS_CAP - 1);
  while (missUsed[h]) { if (missKeys[h] == k) return; h = (h + 1) & (MISS_CAP - 1); }
  if (missCount > (int)(MISS_CAP * 3 / 4)) return;
  missUsed[h] = 1; missKeys[h] = k; missCount++;
}

// ---- lockstep verification: rolling hash of full CPU state per instruction ------
static uint64_t chain = 1469598103934665603ull;
static uint64_t insnCount = 0;
FILE* verifyOut = NULL;
int traceN = 0;

void recomp_verifyHook(Cpu* cpu) {
  uint64_t cyc = ((Snes*) cpu->mem)->cycles;
  uint64_t v[6] = {
    ((uint64_t) cpu->k << 16) | cpu->pc,
    ((uint64_t) cpu->a << 32) | ((uint64_t) cpu->x << 16) | cpu->y,
    ((uint64_t) cpu->sp << 32) | ((uint64_t) cpu->dp << 16) | cpu->db,
    cpu->n | (cpu->v << 1) | (cpu->mf << 2) | (cpu->xf << 3) | (cpu->d << 4) | (cpu->i << 5) | (cpu->z << 6) | (cpu->c << 7) | (cpu->e << 8),
    cyc, ((Snes*) cpu->mem)->frames };
  for (int i = 0; i < 6; i++) { chain ^= v[i]; chain *= 1099511628211ull; }
  insnCount++;
  if (traceN > 0 && insnCount <= (uint64_t) traceN && verifyOut) fprintf(verifyOut, "T %llu %02x:%04x a=%04x x=%04x y=%04x sp=%04x cyc=%llu\n", (unsigned long long) insnCount, cpu->k, cpu->pc, cpu->a, cpu->x, cpu->y, cpu->sp, (unsigned long long) cyc);
  if ((insnCount & 0xfffff) == 0 && verifyOut)
    fprintf(verifyOut, "%llu %016llx\n", (unsigned long long) insnCount, (unsigned long long) chain);
}
