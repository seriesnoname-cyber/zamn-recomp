package org.zamn.recomp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Asks for your own dump of Zombies Ate My Neighbors (USA) once, copies it into the
 * app's private storage, then starts the game. The ROM is never bundled with the app.
 */
public class LauncherActivity extends Activity {
    private static final int PICK = 1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (new File(getFilesDir(), "rom.sfc").length() == 1048576) { start(); return; }
        pick();
    }

    private void pick() {
        Toast.makeText(this, "Escolha o seu dump da ROM (.sfc / .smc)", Toast.LENGTH_LONG).show();
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, PICK);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req != PICK || res != RESULT_OK || data == null) { finish(); return; }
        try {
            Uri u = data.getData();
            File out = new File(getFilesDir(), "rom.sfc");
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            try (InputStream in = getContentResolver().openInputStream(u)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            }
            byte[] all = bos.toByteArray();
            int off = (all.length % 1024 == 512) ? 512 : 0;      // drop a 512-byte copier header if present
            try (OutputStream o = new FileOutputStream(out)) { o.write(all, off, all.length - off); }
            if (out.length() != 1048576) { out.delete(); Toast.makeText(this, "Arquivo inválido: esperado 1 MB (LoROM).", Toast.LENGTH_LONG).show(); finish(); return; }
            start();
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao copiar a ROM: " + e, Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void start() {
        // SDL's native side reads <internal storage>/rom.sfc  (== getFilesDir())
        startActivity(new Intent(this, GameActivity.class));
        finish();
    }
}
