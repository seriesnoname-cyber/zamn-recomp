package org.zamn.recomp;

import org.libsdl.app.SDLActivity;

/** SDL hosts the native game (libmain.so). */
public class GameActivity extends SDLActivity {
}
