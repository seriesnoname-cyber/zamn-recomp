#!/bin/bash
# Fetches SDL2 and installs its Java glue into the Android project. Run once (CI does this too).
set -e
cd "$(dirname "$0")/.."
[ -d third_party/SDL ] || git clone --depth 1 --branch release-2.30.8 https://github.com/libsdl-org/SDL.git third_party/SDL
mkdir -p android/app/src/main/java
cp -r third_party/SDL/android-project/app/src/main/java/org android/app/src/main/java/
echo "ok"
