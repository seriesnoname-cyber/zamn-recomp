
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "cpu.h"
#ifdef RECOMP_VERIFY
extern void recomp_verifyHook(Cpu* cpu);
#endif
extern int recomp_dispatch(Cpu* cpu);
extern void recomp_logMiss(Cpu* cpu);
#include "statehandler.h"

static uint8_t cpu_read(Cpu* cpu, uint32_t adr);
static void cpu_write(Cpu* cpu, uint32_t adr, uint8_t val);
static void cpu_idle(Cpu* cpu);
static void cpu_idleWait(Cpu* cpu);
static void cpu_checkInt(Cpu* cpu);
static uint8_t cpu_readOpcode(Cpu* cpu);
static uint16_t cpu_readOpcodeWord(Cpu* cpu, bool intCheck);
static uint8_t cpu_getFlags(Cpu* cpu);
static void cpu_setFlags(Cpu* cpu, uint8_t value);
static void cpu_setZN(Cpu* cpu, uint16_t value, bool byte);
static void cpu_doBranch(Cpu* cpu, bool check);
static uint8_t cpu_pullByte(Cpu* cpu);
static void cpu_pushByte(Cpu* cpu, uint8_t value);
static uint16_t cpu_pullWord(Cpu* cpu, bool intCheck);
static void cpu_pushWord(Cpu* cpu, uint16_t value, bool intCheck);
static uint16_t cpu_readWord(Cpu* cpu, uint32_t adrl, uint32_t adrh, bool intCheck);
static void cpu_writeWord(Cpu* cpu, uint32_t adrl, uint32_t adrh, uint16_t value, bool reversed, bool intCheck);
static void cpu_doInterrupt(Cpu* cpu);
static inline __attribute__((always_inline)) void cpu_doOpcode(Cpu* cpu, uint8_t opcode);

// addressing modes and opcode functions not declared, only used after defintions

Cpu* cpu_init(void* mem, CpuReadHandler read, CpuWriteHandler write, CpuIdleHandler idle) {
  Cpu* cpu = malloc(sizeof(Cpu));
  cpu->mem = mem;
  cpu->read = read;
  cpu->write = write;
  cpu->idle = idle;
  return cpu;
}

void cpu_free(Cpu* cpu) {
  free(cpu);
}

void cpu_reset(Cpu* cpu, bool hard) {
  if(hard) {
    cpu->a = 0;
    cpu->x = 0;
    cpu->y = 0;
    cpu->sp = 0;
    cpu->pc = 0;
    cpu->dp = 0;
    cpu->k = 0;
    cpu->db = 0;
    cpu->c = false;
    cpu->z = false;
    cpu->v = false;
    cpu->n = false;
    cpu->i = false;
    cpu->d = false;
    cpu->xf = false;
    cpu->mf = false;
    cpu->e = false;
    cpu->irqWanted = false;
  }
  cpu->waiting = false;
  cpu->stopped = false;
  cpu->nmiWanted = false;
  cpu->intWanted = false;
  cpu->resetWanted = true;
}

void cpu_handleState(Cpu* cpu, StateHandler* sh) {
  sh_handleBools(sh,
    &cpu->c, &cpu->z, &cpu->v, &cpu->n, &cpu->i, &cpu->d, &cpu->xf, &cpu->mf, &cpu->e, &cpu->waiting, &cpu->stopped,
    &cpu->irqWanted, &cpu->nmiWanted, &cpu->intWanted, &cpu->resetWanted, NULL
  );
  sh_handleBytes(sh, &cpu->k, &cpu->db, NULL);
  sh_handleWords(sh, &cpu->a, &cpu->x, &cpu->y, &cpu->sp, &cpu->pc, &cpu->dp, NULL);
}

void cpu_runOpcode(Cpu* cpu) {
  if(cpu->resetWanted) {
    cpu->resetWanted = false;
    // reset: brk/interrupt without writes
    cpu_read(cpu, (cpu->k << 16) | cpu->pc);
    cpu_idle(cpu);
    cpu_read(cpu, 0x100 | (cpu->sp-- & 0xff));
    cpu_read(cpu, 0x100 | (cpu->sp-- & 0xff));
    cpu_read(cpu, 0x100 | (cpu->sp-- & 0xff));
    cpu->sp = (cpu->sp & 0xff) | 0x100;
    cpu->e = true;
    cpu->i = true;
    cpu->d = false;
    cpu_setFlags(cpu, cpu_getFlags(cpu)); // updates x and m flags, clears upper half of x and y if needed
    cpu->k = 0;
    cpu->pc = cpu_readWord(cpu, 0xfffc, 0xfffd, false);
    return;
  }
  if(cpu->stopped) {
    cpu_idleWait(cpu);
    return;
  }
  if(cpu->waiting) {
    if(cpu->irqWanted || cpu->nmiWanted) {
      cpu->waiting = false;
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_idle(cpu);
      return;
    } else {
      cpu_idleWait(cpu);
      return;
    }
  }
  // not stopped or waiting, execute a opcode or go to interrupt
  if(cpu->intWanted) {
    cpu_read(cpu, (cpu->k << 16) | cpu->pc);
    cpu_doInterrupt(cpu);
  } else {
    uint8_t opcode = cpu_readOpcode(cpu);
    cpu_doOpcode(cpu, opcode);
  }
#ifdef RECOMP_VERIFY
  recomp_verifyHook(cpu);
#endif
}

void cpu_nmi(Cpu* cpu) {
  cpu->nmiWanted = true;
}

void cpu_setIrq(Cpu* cpu, bool state) {
  cpu->irqWanted = state;
}

static uint8_t cpu_read(Cpu* cpu, uint32_t adr) {
  return cpu->read(cpu->mem, adr);
}

static void cpu_write(Cpu* cpu, uint32_t adr, uint8_t val) {
  cpu->write(cpu->mem, adr, val);
}

static void cpu_idle(Cpu* cpu) {
  cpu->idle(cpu->mem, false);
}

static void cpu_idleWait(Cpu* cpu) {
  cpu->idle(cpu->mem, true);
}

static void cpu_checkInt(Cpu* cpu) {
  cpu->intWanted = cpu->nmiWanted || (cpu->irqWanted && !cpu->i);
}

static uint8_t cpu_readOpcode(Cpu* cpu) {
  return cpu_read(cpu, (cpu->k << 16) | cpu->pc++);
}

static uint16_t cpu_readOpcodeWord(Cpu* cpu, bool intCheck) {
  uint8_t low = cpu_readOpcode(cpu);
  if(intCheck) cpu_checkInt(cpu);
  return low | (cpu_readOpcode(cpu) << 8);
}

static uint8_t cpu_getFlags(Cpu* cpu) {
  uint8_t val = cpu->n << 7;
  val |= cpu->v << 6;
  val |= cpu->mf << 5;
  val |= cpu->xf << 4;
  val |= cpu->d << 3;
  val |= cpu->i << 2;
  val |= cpu->z << 1;
  val |= cpu->c;
  return val;
}

static void cpu_setFlags(Cpu* cpu, uint8_t val) {
  cpu->n = val & 0x80;
  cpu->v = val & 0x40;
  cpu->mf = val & 0x20;
  cpu->xf = val & 0x10;
  cpu->d = val & 8;
  cpu->i = val & 4;
  cpu->z = val & 2;
  cpu->c = val & 1;
  if(cpu->e) {
    cpu->mf = true;
    cpu->xf = true;
    cpu->sp = (cpu->sp & 0xff) | 0x100;
  }
  if(cpu->xf) {
    cpu->x &= 0xff;
    cpu->y &= 0xff;
  }
}

static void cpu_setZN(Cpu* cpu, uint16_t value, bool byte) {
  if(byte) {
    cpu->z = (value & 0xff) == 0;
    cpu->n = value & 0x80;
  } else {
    cpu->z = value == 0;
    cpu->n = value & 0x8000;
  }
}

static void cpu_doBranch(Cpu* cpu, bool check) {
  if(!check) cpu_checkInt(cpu);
  uint8_t value = cpu_readOpcode(cpu);
  if(check) {
    cpu_checkInt(cpu);
    cpu_idle(cpu); // taken branch: 1 extra cycle
    cpu->pc += (int8_t) value;
  }
}

static uint8_t cpu_pullByte(Cpu* cpu) {
  cpu->sp++;
  if(cpu->e) cpu->sp = (cpu->sp & 0xff) | 0x100;
  return cpu_read(cpu, cpu->sp);
}

static void cpu_pushByte(Cpu* cpu, uint8_t value) {
  cpu_write(cpu, cpu->sp, value);
  cpu->sp--;
  if(cpu->e) cpu->sp = (cpu->sp & 0xff) | 0x100;
}

static uint16_t cpu_pullWord(Cpu* cpu, bool intCheck) {
  uint8_t value = cpu_pullByte(cpu);
  if(intCheck) cpu_checkInt(cpu);
  return value | (cpu_pullByte(cpu) << 8);
}

static void cpu_pushWord(Cpu* cpu, uint16_t value, bool intCheck) {
  cpu_pushByte(cpu, value >> 8);
  if(intCheck) cpu_checkInt(cpu);
  cpu_pushByte(cpu, value & 0xff);
}

static uint16_t cpu_readWord(Cpu* cpu, uint32_t adrl, uint32_t adrh, bool intCheck) {
  uint8_t value = cpu_read(cpu, adrl);
  if(intCheck) cpu_checkInt(cpu);
  return value | (cpu_read(cpu, adrh) << 8);
}

static void cpu_writeWord(Cpu* cpu, uint32_t adrl, uint32_t adrh, uint16_t value, bool reversed, bool intCheck) {
  if(reversed) {
    cpu_write(cpu, adrh, value >> 8);
    if(intCheck) cpu_checkInt(cpu);
    cpu_write(cpu, adrl, value & 0xff);
  } else {
    cpu_write(cpu, adrl, value & 0xff);
    if(intCheck) cpu_checkInt(cpu);
    cpu_write(cpu, adrh, value >> 8);
  }
}

static void cpu_doInterrupt(Cpu* cpu) {
  cpu_idle(cpu);
  cpu_pushByte(cpu, cpu->k);
  cpu_pushWord(cpu, cpu->pc, false);
  cpu_pushByte(cpu, cpu_getFlags(cpu));
  cpu->i = true;
  cpu->d = false;
  cpu->k = 0;
  cpu->intWanted = false;
  if(cpu->nmiWanted) {
    cpu->nmiWanted = false;
    cpu->pc = cpu_readWord(cpu, 0xffea, 0xffeb, false);
  } else { // irq
    cpu->pc = cpu_readWord(cpu, 0xffee, 0xffef, false);
  }
}

// addressing modes

static void cpu_adrImp(Cpu* cpu) {
  // only for 2-cycle implied opcodes
  cpu_checkInt(cpu);
  if(cpu->intWanted) {
    // if interrupt detected in 2-cycle implied/accumulator opcode,
    // idle cycle turns into read from pc
    cpu_read(cpu, (cpu->k << 16) | cpu->pc);
  } else {
    cpu_idle(cpu);
  }
}

static uint32_t cpu_adrImm(Cpu* cpu, uint32_t* low, bool xFlag) {
  if((xFlag && cpu->xf) || (!xFlag && cpu->mf)) {
    *low = (cpu->k << 16) | cpu->pc++;
    return 0;
  } else {
    *low = (cpu->k << 16) | cpu->pc++;
    return (cpu->k << 16) | cpu->pc++;
  }
}

static uint32_t cpu_adrDp(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  *low = (cpu->dp + adr) & 0xffff;
  return (cpu->dp + adr + 1) & 0xffff;
}

static uint32_t cpu_adrDpx(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  cpu_idle(cpu);
  *low = (cpu->dp + adr + cpu->x) & 0xffff;
  return (cpu->dp + adr + cpu->x + 1) & 0xffff;
}

static uint32_t cpu_adrDpy(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  cpu_idle(cpu);
  *low = (cpu->dp + adr + cpu->y) & 0xffff;
  return (cpu->dp + adr + cpu->y + 1) & 0xffff;
}

static uint32_t cpu_adrIdp(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  uint16_t pointer = cpu_readWord(cpu, (cpu->dp + adr) & 0xffff, (cpu->dp + adr + 1) & 0xffff, false);
  *low = (cpu->db << 16) + pointer;
  return ((cpu->db << 16) + pointer + 1) & 0xffffff;
}

static uint32_t cpu_adrIdx(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  cpu_idle(cpu);
  uint16_t pointer = cpu_readWord(cpu, (cpu->dp + adr + cpu->x) & 0xffff, (cpu->dp + adr + cpu->x + 1) & 0xffff, false);
  *low = (cpu->db << 16) + pointer;
  return ((cpu->db << 16) + pointer + 1) & 0xffffff;
}

static uint32_t cpu_adrIdy(Cpu* cpu, uint32_t* low, bool write) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  uint16_t pointer = cpu_readWord(cpu, (cpu->dp + adr) & 0xffff, (cpu->dp + adr + 1) & 0xffff, false);
  // writing opcode or x = 0 or page crossed: 1 extra cycle
  if(write || !cpu->xf || ((pointer >> 8) != ((pointer + cpu->y) >> 8))) cpu_idle(cpu);
  *low = ((cpu->db << 16) + pointer + cpu->y) & 0xffffff;
  return ((cpu->db << 16) + pointer + cpu->y + 1) & 0xffffff;
}

static uint32_t cpu_adrIdl(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  uint32_t pointer = cpu_readWord(cpu, (cpu->dp + adr) & 0xffff, (cpu->dp + adr + 1) & 0xffff, false);
  pointer |= cpu_read(cpu, (cpu->dp + adr + 2) & 0xffff) << 16;
  *low = pointer;
  return (pointer + 1) & 0xffffff;
}

static uint32_t cpu_adrIly(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  if(cpu->dp & 0xff) cpu_idle(cpu); // dpr not 0: 1 extra cycle
  uint32_t pointer = cpu_readWord(cpu, (cpu->dp + adr) & 0xffff, (cpu->dp + adr + 1) & 0xffff, false);
  pointer |= cpu_read(cpu, (cpu->dp + adr + 2) & 0xffff) << 16;
  *low = (pointer + cpu->y) & 0xffffff;
  return (pointer + cpu->y + 1) & 0xffffff;
}

static uint32_t cpu_adrSr(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  cpu_idle(cpu);
  *low = (cpu->sp + adr) & 0xffff;
  return (cpu->sp + adr + 1) & 0xffff;
}

static uint32_t cpu_adrIsy(Cpu* cpu, uint32_t* low) {
  uint8_t adr = cpu_readOpcode(cpu);
  cpu_idle(cpu);
  uint16_t pointer = cpu_readWord(cpu, (cpu->sp + adr) & 0xffff, (cpu->sp + adr + 1) & 0xffff, false);
  cpu_idle(cpu);
  *low = ((cpu->db << 16) + pointer + cpu->y) & 0xffffff;
  return ((cpu->db << 16) + pointer + cpu->y + 1) & 0xffffff;
}

static uint32_t cpu_adrAbs(Cpu* cpu, uint32_t* low) {
  uint16_t adr = cpu_readOpcodeWord(cpu, false);
  *low = (cpu->db << 16) + adr;
  return ((cpu->db << 16) + adr + 1) & 0xffffff;
}

static uint32_t cpu_adrAbx(Cpu* cpu, uint32_t* low, bool write) {
  uint16_t adr = cpu_readOpcodeWord(cpu, false);
  // writing opcode or x = 0 or page crossed: 1 extra cycle
  if(write || !cpu->xf || ((adr >> 8) != ((adr + cpu->x) >> 8))) cpu_idle(cpu);
  *low = ((cpu->db << 16) + adr + cpu->x) & 0xffffff;
  return ((cpu->db << 16) + adr + cpu->x + 1) & 0xffffff;
}

static uint32_t cpu_adrAby(Cpu* cpu, uint32_t* low, bool write) {
  uint16_t adr = cpu_readOpcodeWord(cpu, false);
  // writing opcode or x = 0 or page crossed: 1 extra cycle
  if(write || !cpu->xf || ((adr >> 8) != ((adr + cpu->y) >> 8))) cpu_idle(cpu);
  *low = ((cpu->db << 16) + adr + cpu->y) & 0xffffff;
  return ((cpu->db << 16) + adr + cpu->y + 1) & 0xffffff;
}

static uint32_t cpu_adrAbl(Cpu* cpu, uint32_t* low) {
  uint32_t adr = cpu_readOpcodeWord(cpu, false);
  adr |= cpu_readOpcode(cpu) << 16;
  *low = adr;
  return (adr + 1) & 0xffffff;
}

static uint32_t cpu_adrAlx(Cpu* cpu, uint32_t* low) {
  uint32_t adr = cpu_readOpcodeWord(cpu, false);
  adr |= cpu_readOpcode(cpu) << 16;
  *low = (adr + cpu->x) & 0xffffff;
  return (adr + cpu->x + 1) & 0xffffff;
}

// opcode functions

static void cpu_and(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low);
    cpu->a = (cpu->a & 0xff00) | ((cpu->a & value) & 0xff);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true);
    cpu->a &= value;
  }
  cpu_setZN(cpu, cpu->a, cpu->mf);
}

static void cpu_ora(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low);
    cpu->a = (cpu->a & 0xff00) | ((cpu->a | value) & 0xff);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true);
    cpu->a |= value;
  }
  cpu_setZN(cpu, cpu->a, cpu->mf);
}

static void cpu_eor(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low);
    cpu->a = (cpu->a & 0xff00) | ((cpu->a ^ value) & 0xff);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true);
    cpu->a ^= value;
  }
  cpu_setZN(cpu, cpu->a, cpu->mf);
}

static void cpu_adc(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low);
    int result = 0;
    if(cpu->d) {
      result = (cpu->a & 0xf) + (value & 0xf) + cpu->c;
      if(result > 0x9) result = ((result + 0x6) & 0xf) + 0x10;
      result = (cpu->a & 0xf0) + (value & 0xf0) + result;
    } else {
      result = (cpu->a & 0xff) + value + cpu->c;
    }
    cpu->v = (cpu->a & 0x80) == (value & 0x80) && (value & 0x80) != (result & 0x80);
    if(cpu->d && result > 0x9f) result += 0x60;
    cpu->c = result > 0xff;
    cpu->a = (cpu->a & 0xff00) | (result & 0xff);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true);
    int result = 0;
    if(cpu->d) {
      result = (cpu->a & 0xf) + (value & 0xf) + cpu->c;
      if(result > 0x9) result = ((result + 0x6) & 0xf) + 0x10;
      result = (cpu->a & 0xf0) + (value & 0xf0) + result;
      if(result > 0x9f) result = ((result + 0x60) & 0xff) + 0x100;
      result = (cpu->a & 0xf00) + (value & 0xf00) + result;
      if(result > 0x9ff) result = ((result + 0x600) & 0xfff) + 0x1000;
      result = (cpu->a & 0xf000) + (value & 0xf000) + result;
    } else {
      result = cpu->a + value + cpu->c;
    }
    cpu->v = (cpu->a & 0x8000) == (value & 0x8000) && (value & 0x8000) != (result & 0x8000);
    if(cpu->d && result > 0x9fff) result += 0x6000;
    cpu->c = result > 0xffff;
    cpu->a = result;
  }
  cpu_setZN(cpu, cpu->a, cpu->mf);
}

static void cpu_sbc(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low) ^ 0xff;
    int result = 0;
    if(cpu->d) {
      result = (cpu->a & 0xf) + (value & 0xf) + cpu->c;
      if(result < 0x10) result = (result - 0x6) & ((result - 0x6 < 0) ? 0xf : 0x1f);
      result = (cpu->a & 0xf0) + (value & 0xf0) + result;
    } else {
      result = (cpu->a & 0xff) + value + cpu->c;
    }
    cpu->v = (cpu->a & 0x80) == (value & 0x80) && (value & 0x80) != (result & 0x80);
    if(cpu->d && result < 0x100) result -= 0x60;
    cpu->c = result > 0xff;
    cpu->a = (cpu->a & 0xff00) | (result & 0xff);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true) ^ 0xffff;
    int result = 0;
    if(cpu->d) {
      result = (cpu->a & 0xf) + (value & 0xf) + cpu->c;
      if(result < 0x10) result = (result - 0x6) & ((result - 0x6 < 0) ? 0xf : 0x1f);
      result = (cpu->a & 0xf0) + (value & 0xf0) + result;
      if(result < 0x100) result = (result - 0x60) & ((result - 0x60 < 0) ? 0xff : 0x1ff);
      result = (cpu->a & 0xf00) + (value & 0xf00) + result;
      if(result < 0x1000) result = (result - 0x600) & ((result - 0x600 < 0) ? 0xfff : 0x1fff);
      result = (cpu->a & 0xf000) + (value & 0xf000) + result;
    } else {
      result = cpu->a + value + cpu->c;
    }
    cpu->v = (cpu->a & 0x8000) == (value & 0x8000) && (value & 0x8000) != (result & 0x8000);
    if(cpu->d && result < 0x10000) result -= 0x6000;
    cpu->c = result > 0xffff;
    cpu->a = result;
  }
  cpu_setZN(cpu, cpu->a, cpu->mf);
}

static void cpu_cmp(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low) ^ 0xff;
    result = (cpu->a & 0xff) + value + 1;
    cpu->c = result > 0xff;
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true) ^ 0xffff;
    result = cpu->a + value + 1;
    cpu->c = result > 0xffff;
  }
  cpu_setZN(cpu, result, cpu->mf);
}

static void cpu_cpx(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->xf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low) ^ 0xff;
    result = (cpu->x & 0xff) + value + 1;
    cpu->c = result > 0xff;
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true) ^ 0xffff;
    result = cpu->x + value + 1;
    cpu->c = result > 0xffff;
  }
  cpu_setZN(cpu, result, cpu->xf);
}

static void cpu_cpy(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->xf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low) ^ 0xff;
    result = (cpu->y & 0xff) + value + 1;
    cpu->c = result > 0xff;
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true) ^ 0xffff;
    result = cpu->y + value + 1;
    cpu->c = result > 0xffff;
  }
  cpu_setZN(cpu, result, cpu->xf);
}

static void cpu_bit(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    uint8_t value = cpu_read(cpu, low);
    uint8_t result = (cpu->a & 0xff) & value;
    cpu->z = result == 0;
    cpu->n = value & 0x80;
    cpu->v = value & 0x40;
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, true);
    uint16_t result = cpu->a & value;
    cpu->z = result == 0;
    cpu->n = value & 0x8000;
    cpu->v = value & 0x4000;
  }
}

static void cpu_lda(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    cpu->a = (cpu->a & 0xff00) | cpu_read(cpu, low);
  } else {
    cpu->a = cpu_readWord(cpu, low, high, true);
  }
  cpu_setZN(cpu, cpu->a, cpu->mf);
}

static void cpu_ldx(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->xf) {
    cpu_checkInt(cpu);
    cpu->x = cpu_read(cpu, low);
  } else {
    cpu->x = cpu_readWord(cpu, low, high, true);
  }
  cpu_setZN(cpu, cpu->x, cpu->xf);
}

static void cpu_ldy(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->xf) {
    cpu_checkInt(cpu);
    cpu->y = cpu_read(cpu, low);
  } else {
    cpu->y = cpu_readWord(cpu, low, high, true);
  }
  cpu_setZN(cpu, cpu->y, cpu->xf);
}

static void cpu_sta(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    cpu_write(cpu, low, cpu->a);
  } else {
    cpu_writeWord(cpu, low, high, cpu->a, false, true);
  }
}

static void cpu_stx(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->xf) {
    cpu_checkInt(cpu);
    cpu_write(cpu, low, cpu->x);
  } else {
    cpu_writeWord(cpu, low, high, cpu->x, false, true);
  }
}

static void cpu_sty(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->xf) {
    cpu_checkInt(cpu);
    cpu_write(cpu, low, cpu->y);
  } else {
    cpu_writeWord(cpu, low, high, cpu->y, false, true);
  }
}

static void cpu_stz(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    cpu_checkInt(cpu);
    cpu_write(cpu, low, 0);
  } else {
    cpu_writeWord(cpu, low, high, 0, false, true);
  }
}

static void cpu_ror(Cpu* cpu, uint32_t low, uint32_t high) {
  bool carry = false;
  int result = 0;
  if(cpu->mf) {
    uint8_t value = cpu_read(cpu, low);
    cpu_idle(cpu);
    carry = value & 1;
    result = (value >> 1) | (cpu->c << 7);
    cpu_checkInt(cpu);
    cpu_write(cpu, low, result);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, false);
    cpu_idle(cpu);
    carry = value & 1;
    result = (value >> 1) | (cpu->c << 15);
    cpu_writeWord(cpu, low, high, result, true, true);
  }
  cpu_setZN(cpu, result, cpu->mf);
  cpu->c = carry;
}

static void cpu_rol(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->mf) {
    result = (cpu_read(cpu, low) << 1) | cpu->c;
    cpu_idle(cpu);
    cpu->c = result & 0x100;
    cpu_checkInt(cpu);
    cpu_write(cpu, low, result);
  } else {
    result = (cpu_readWord(cpu, low, high, false) << 1) | cpu->c;
    cpu_idle(cpu);
    cpu->c = result & 0x10000;
    cpu_writeWord(cpu, low, high, result, true, true);
  }
  cpu_setZN(cpu, result, cpu->mf);
}

static void cpu_lsr(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->mf) {
    uint8_t value = cpu_read(cpu, low);
    cpu_idle(cpu);
    cpu->c = value & 1;
    result = value >> 1;
    cpu_checkInt(cpu);
    cpu_write(cpu, low, result);
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, false);
    cpu_idle(cpu);
    cpu->c = value & 1;
    result = value >> 1;
    cpu_writeWord(cpu, low, high, result, true, true);
  }
  cpu_setZN(cpu, result, cpu->mf);
}

static void cpu_asl(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->mf) {
    result = cpu_read(cpu, low) << 1;
    cpu_idle(cpu);
    cpu->c = result & 0x100;
    cpu_checkInt(cpu);
    cpu_write(cpu, low, result);
  } else {
    result = cpu_readWord(cpu, low, high, false) << 1;
    cpu_idle(cpu);
    cpu->c = result & 0x10000;
    cpu_writeWord(cpu, low, high, result, true, true);
  }
  cpu_setZN(cpu, result, cpu->mf);
}

static void cpu_inc(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->mf) {
    result = cpu_read(cpu, low) + 1;
    cpu_idle(cpu);
    cpu_checkInt(cpu);
    cpu_write(cpu, low, result);
  } else {
    result = cpu_readWord(cpu, low, high, false) + 1;
    cpu_idle(cpu);
    cpu_writeWord(cpu, low, high, result, true, true);
  }
  cpu_setZN(cpu, result, cpu->mf);
}

static void cpu_dec(Cpu* cpu, uint32_t low, uint32_t high) {
  int result = 0;
  if(cpu->mf) {
    result = cpu_read(cpu, low) - 1;
    cpu_idle(cpu);
    cpu_checkInt(cpu);
    cpu_write(cpu, low, result);
  } else {
    result = cpu_readWord(cpu, low, high, false) - 1;
    cpu_idle(cpu);
    cpu_writeWord(cpu, low, high, result, true, true);
  }
  cpu_setZN(cpu, result, cpu->mf);
}

static void cpu_tsb(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    uint8_t value = cpu_read(cpu, low);
    cpu_idle(cpu);
    cpu->z = ((cpu->a & 0xff) & value) == 0;
    cpu_checkInt(cpu);
    cpu_write(cpu, low, value | (cpu->a & 0xff));
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, false);
    cpu_idle(cpu);
    cpu->z = (cpu->a & value) == 0;
    cpu_writeWord(cpu, low, high, value | cpu->a, true, true);
  }
}

static void cpu_trb(Cpu* cpu, uint32_t low, uint32_t high) {
  if(cpu->mf) {
    uint8_t value = cpu_read(cpu, low);
    cpu_idle(cpu);
    cpu->z = ((cpu->a & 0xff) & value) == 0;
    cpu_checkInt(cpu);
    cpu_write(cpu, low, value & ~(cpu->a & 0xff));
  } else {
    uint16_t value = cpu_readWord(cpu, low, high, false);
    cpu_idle(cpu);
    cpu->z = (cpu->a & value) == 0;
    cpu_writeWord(cpu, low, high, value & ~cpu->a, true, true);
  }
}

static inline __attribute__((always_inline)) void cpu_doOpcode(Cpu* cpu, uint8_t opcode) {
  switch(opcode) {
    case 0x00: { // brk imm(s)
      cpu_readOpcode(cpu);
      cpu_pushByte(cpu, cpu->k);
      cpu_pushWord(cpu, cpu->pc, false);
      cpu_pushByte(cpu, cpu_getFlags(cpu));
      cpu->i = true;
      cpu->d = false;
      cpu->k = 0;
      cpu->pc = cpu_readWord(cpu, 0xffe6, 0xffe7, true);
      break;
    }
    case 0x01: { // ora idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x02: { // cop imm(s)
      cpu_readOpcode(cpu);
      cpu_pushByte(cpu, cpu->k);
      cpu_pushWord(cpu, cpu->pc, false);
      cpu_pushByte(cpu, cpu_getFlags(cpu));
      cpu->i = true;
      cpu->d = false;
      cpu->k = 0;
      cpu->pc = cpu_readWord(cpu, 0xffe4, 0xffe5, true);
      break;
    }
    case 0x03: { // ora sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x04: { // tsb dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_tsb(cpu, low, high);
      break;
    }
    case 0x05: { // ora dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x06: { // asl dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_asl(cpu, low, high);
      break;
    }
    case 0x07: { // ora idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x08: { // php imp
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_pushByte(cpu, cpu_getFlags(cpu));
      break;
    }
    case 0x09: { // ora imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x0a: { // asla imp
      cpu_adrImp(cpu);
      if(cpu->mf) {
        cpu->c = cpu->a & 0x80;
        cpu->a = (cpu->a & 0xff00) | ((cpu->a << 1) & 0xff);
      } else {
        cpu->c = cpu->a & 0x8000;
        cpu->a <<= 1;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x0b: { // phd imp
      cpu_idle(cpu);
      cpu_pushWord(cpu, cpu->dp, true);
      break;
    }
    case 0x0c: { // tsb abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_tsb(cpu, low, high);
      break;
    }
    case 0x0d: { // ora abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x0e: { // asl abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_asl(cpu, low, high);
      break;
    }
    case 0x0f: { // ora abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x10: { // bpl rel
      cpu_doBranch(cpu, !cpu->n);
      break;
    }
    case 0x11: { // ora idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x12: { // ora idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x13: { // ora isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x14: { // trb dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_trb(cpu, low, high);
      break;
    }
    case 0x15: { // ora dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x16: { // asl dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_asl(cpu, low, high);
      break;
    }
    case 0x17: { // ora ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x18: { // clc imp
      cpu_adrImp(cpu);
      cpu->c = false;
      break;
    }
    case 0x19: { // ora aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x1a: { // inca imp
      cpu_adrImp(cpu);
      if(cpu->mf) {
        cpu->a = (cpu->a & 0xff00) | ((cpu->a + 1) & 0xff);
      } else {
        cpu->a++;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x1b: { // tcs imp
      cpu_adrImp(cpu);
      cpu->sp = cpu->a;
      break;
    }
    case 0x1c: { // trb abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_trb(cpu, low, high);
      break;
    }
    case 0x1d: { // ora abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x1e: { // asl abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_asl(cpu, low, high);
      break;
    }
    case 0x1f: { // ora alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_ora(cpu, low, high);
      break;
    }
    case 0x20: { // jsr abs
      uint16_t value = cpu_readOpcodeWord(cpu, false);
      cpu_idle(cpu);
      cpu_pushWord(cpu, cpu->pc - 1, true);
      cpu->pc = value;
      break;
    }
    case 0x21: { // and idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x22: { // jsl abl
      uint16_t value = cpu_readOpcodeWord(cpu, false);
      cpu_pushByte(cpu, cpu->k);
      cpu_idle(cpu);
      uint8_t newK = cpu_readOpcode(cpu);
      cpu_pushWord(cpu, cpu->pc - 1, true);
      cpu->pc = value;
      cpu->k = newK;
      break;
    }
    case 0x23: { // and sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x24: { // bit dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_bit(cpu, low, high);
      break;
    }
    case 0x25: { // and dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x26: { // rol dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_rol(cpu, low, high);
      break;
    }
    case 0x27: { // and idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x28: { // plp imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_setFlags(cpu, cpu_pullByte(cpu));
      break;
    }
    case 0x29: { // and imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x2a: { // rola imp
      cpu_adrImp(cpu);
      int result = (cpu->a << 1) | cpu->c;
      if(cpu->mf) {
        cpu->c = result & 0x100;
        cpu->a = (cpu->a & 0xff00) | (result & 0xff);
      } else {
        cpu->c = result & 0x10000;
        cpu->a = result;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x2b: { // pld imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      cpu->dp = cpu_pullWord(cpu, true);
      cpu_setZN(cpu, cpu->dp, false);
      break;
    }
    case 0x2c: { // bit abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_bit(cpu, low, high);
      break;
    }
    case 0x2d: { // and abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x2e: { // rol abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_rol(cpu, low, high);
      break;
    }
    case 0x2f: { // and abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x30: { // bmi rel
      cpu_doBranch(cpu, cpu->n);
      break;
    }
    case 0x31: { // and idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x32: { // and idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x33: { // and isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x34: { // bit dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_bit(cpu, low, high);
      break;
    }
    case 0x35: { // and dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x36: { // rol dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_rol(cpu, low, high);
      break;
    }
    case 0x37: { // and ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x38: { // sec imp
      cpu_adrImp(cpu);
      cpu->c = true;
      break;
    }
    case 0x39: { // and aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x3a: { // deca imp
      cpu_adrImp(cpu);
      if(cpu->mf) {
        cpu->a = (cpu->a & 0xff00) | ((cpu->a - 1) & 0xff);
      } else {
        cpu->a--;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x3b: { // tsc imp
      cpu_adrImp(cpu);
      cpu->a = cpu->sp;
      cpu_setZN(cpu, cpu->a, false);
      break;
    }
    case 0x3c: { // bit abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_bit(cpu, low, high);
      break;
    }
    case 0x3d: { // and abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x3e: { // rol abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_rol(cpu, low, high);
      break;
    }
    case 0x3f: { // and alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_and(cpu, low, high);
      break;
    }
    case 0x40: { // rti imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      cpu_setFlags(cpu, cpu_pullByte(cpu));
      cpu->pc = cpu_pullWord(cpu, false);
      cpu_checkInt(cpu);
      cpu->k = cpu_pullByte(cpu);
      break;
    }
    case 0x41: { // eor idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x42: { // wdm imm(s)
      cpu_checkInt(cpu);
      cpu_readOpcode(cpu);
      break;
    }
    case 0x43: { // eor sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x44: { // mvp bm
      uint8_t dest = cpu_readOpcode(cpu);
      uint8_t src = cpu_readOpcode(cpu);
      cpu->db = dest;
      cpu_write(cpu, (dest << 16) | cpu->y, cpu_read(cpu, (src << 16) | cpu->x));
      cpu->a--;
      cpu->x--;
      cpu->y--;
      if(cpu->a != 0xffff) {
        cpu->pc -= 3;
      }
      if(cpu->xf) {
        cpu->x &= 0xff;
        cpu->y &= 0xff;
      }
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0x45: { // eor dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x46: { // lsr dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_lsr(cpu, low, high);
      break;
    }
    case 0x47: { // eor idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x48: { // pha imp
      cpu_idle(cpu);
      if(cpu->mf) {
        cpu_checkInt(cpu);
        cpu_pushByte(cpu, cpu->a);
      } else {
        cpu_pushWord(cpu, cpu->a, true);
      }
      break;
    }
    case 0x49: { // eor imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x4a: { // lsra imp
      cpu_adrImp(cpu);
      cpu->c = cpu->a & 1;
      if(cpu->mf) {
        cpu->a = (cpu->a & 0xff00) | ((cpu->a >> 1) & 0x7f);
      } else {
        cpu->a >>= 1;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x4b: { // phk imp
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_pushByte(cpu, cpu->k);
      break;
    }
    case 0x4c: { // jmp abs
      cpu->pc = cpu_readOpcodeWord(cpu, true);
      break;
    }
    case 0x4d: { // eor abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x4e: { // lsr abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_lsr(cpu, low, high);
      break;
    }
    case 0x4f: { // eor abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x50: { // bvc rel
      cpu_doBranch(cpu, !cpu->v);
      break;
    }
    case 0x51: { // eor idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x52: { // eor idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x53: { // eor isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x54: { // mvn bm
      uint8_t dest = cpu_readOpcode(cpu);
      uint8_t src = cpu_readOpcode(cpu);
      cpu->db = dest;
      cpu_write(cpu, (dest << 16) | cpu->y, cpu_read(cpu, (src << 16) | cpu->x));
      cpu->a--;
      cpu->x++;
      cpu->y++;
      if(cpu->a != 0xffff) {
        cpu->pc -= 3;
      }
      if(cpu->xf) {
        cpu->x &= 0xff;
        cpu->y &= 0xff;
      }
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0x55: { // eor dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x56: { // lsr dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_lsr(cpu, low, high);
      break;
    }
    case 0x57: { // eor ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x58: { // cli imp
      cpu_adrImp(cpu);
      cpu->i = false;
      break;
    }
    case 0x59: { // eor aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x5a: { // phy imp
      cpu_idle(cpu);
      if(cpu->xf) {
        cpu_checkInt(cpu);
        cpu_pushByte(cpu, cpu->y);
      } else {
        cpu_pushWord(cpu, cpu->y, true);
      }
      break;
    }
    case 0x5b: { // tcd imp
      cpu_adrImp(cpu);
      cpu->dp = cpu->a;
      cpu_setZN(cpu, cpu->dp, false);
      break;
    }
    case 0x5c: { // jml abl
      uint16_t value = cpu_readOpcodeWord(cpu, false);
      cpu_checkInt(cpu);
      cpu->k = cpu_readOpcode(cpu);
      cpu->pc = value;
      break;
    }
    case 0x5d: { // eor abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x5e: { // lsr abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_lsr(cpu, low, high);
      break;
    }
    case 0x5f: { // eor alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_eor(cpu, low, high);
      break;
    }
    case 0x60: { // rts imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      cpu->pc = cpu_pullWord(cpu, false) + 1;
      cpu_checkInt(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0x61: { // adc idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x62: { // per rll
      uint16_t value = cpu_readOpcodeWord(cpu, false);
      cpu_idle(cpu);
      cpu_pushWord(cpu, cpu->pc + (int16_t) value, true);
      break;
    }
    case 0x63: { // adc sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x64: { // stz dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_stz(cpu, low, high);
      break;
    }
    case 0x65: { // adc dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x66: { // ror dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_ror(cpu, low, high);
      break;
    }
    case 0x67: { // adc idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x68: { // pla imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      if(cpu->mf) {
        cpu_checkInt(cpu);
        cpu->a = (cpu->a & 0xff00) | cpu_pullByte(cpu);
      } else {
        cpu->a = cpu_pullWord(cpu, true);
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x69: { // adc imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x6a: { // rora imp
      cpu_adrImp(cpu);
      bool carry = cpu->a & 1;
      if(cpu->mf) {
        cpu->a = (cpu->a & 0xff00) | ((cpu->a >> 1) & 0x7f) | (cpu->c << 7);
      } else {
        cpu->a = (cpu->a >> 1) | (cpu->c << 15);
      }
      cpu->c = carry;
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x6b: { // rtl imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      cpu->pc = cpu_pullWord(cpu, false) + 1;
      cpu_checkInt(cpu);
      cpu->k = cpu_pullByte(cpu);
      break;
    }
    case 0x6c: { // jmp ind
      uint16_t adr = cpu_readOpcodeWord(cpu, false);
      cpu->pc = cpu_readWord(cpu, adr, (adr + 1) & 0xffff, true);
      break;
    }
    case 0x6d: { // adc abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x6e: { // ror abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_ror(cpu, low, high);
      break;
    }
    case 0x6f: { // adc abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x70: { // bvs rel
      cpu_doBranch(cpu, cpu->v);
      break;
    }
    case 0x71: { // adc idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x72: { // adc idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x73: { // adc isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x74: { // stz dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_stz(cpu, low, high);
      break;
    }
    case 0x75: { // adc dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x76: { // ror dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_ror(cpu, low, high);
      break;
    }
    case 0x77: { // adc ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x78: { // sei imp
      cpu_adrImp(cpu);
      cpu->i = true;
      break;
    }
    case 0x79: { // adc aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x7a: { // ply imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      if(cpu->xf) {
        cpu_checkInt(cpu);
        cpu->y = cpu_pullByte(cpu);
      } else {
        cpu->y = cpu_pullWord(cpu, true);
      }
      cpu_setZN(cpu, cpu->y, cpu->xf);
      break;
    }
    case 0x7b: { // tdc imp
      cpu_adrImp(cpu);
      cpu->a = cpu->dp;
      cpu_setZN(cpu, cpu->a, false);
      break;
    }
    case 0x7c: { // jmp iax
      uint16_t adr = cpu_readOpcodeWord(cpu, false);
      cpu_idle(cpu);
      cpu->pc = cpu_readWord(cpu, (cpu->k << 16) | ((adr + cpu->x) & 0xffff), (cpu->k << 16) | ((adr + cpu->x + 1) & 0xffff), true);
      break;
    }
    case 0x7d: { // adc abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x7e: { // ror abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_ror(cpu, low, high);
      break;
    }
    case 0x7f: { // adc alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_adc(cpu, low, high);
      break;
    }
    case 0x80: { // bra rel
      cpu_doBranch(cpu, true);
      break;
    }
    case 0x81: { // sta idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x82: { // brl rll
      cpu->pc += (int16_t) cpu_readOpcodeWord(cpu, false);
      cpu_checkInt(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0x83: { // sta sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x84: { // sty dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_sty(cpu, low, high);
      break;
    }
    case 0x85: { // sta dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x86: { // stx dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_stx(cpu, low, high);
      break;
    }
    case 0x87: { // sta idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x88: { // dey imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->y = (cpu->y - 1) & 0xff;
      } else {
        cpu->y--;
      }
      cpu_setZN(cpu, cpu->y, cpu->xf);
      break;
    }
    case 0x89: { // biti imm(m)
      if(cpu->mf) {
        cpu_checkInt(cpu);
        uint8_t result = (cpu->a & 0xff) & cpu_readOpcode(cpu);
        cpu->z = result == 0;
      } else {
        uint16_t result = cpu->a & cpu_readOpcodeWord(cpu, true);
        cpu->z = result == 0;
      }
      break;
    }
    case 0x8a: { // txa imp
      cpu_adrImp(cpu);
      if(cpu->mf) {
        cpu->a = (cpu->a & 0xff00) | (cpu->x & 0xff);
      } else {
        cpu->a = cpu->x;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x8b: { // phb imp
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_pushByte(cpu, cpu->db);
      break;
    }
    case 0x8c: { // sty abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_sty(cpu, low, high);
      break;
    }
    case 0x8d: { // sta abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x8e: { // stx abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_stx(cpu, low, high);
      break;
    }
    case 0x8f: { // sta abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x90: { // bcc rel
      cpu_doBranch(cpu, !cpu->c);
      break;
    }
    case 0x91: { // sta idy
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, true);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x92: { // sta idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x93: { // sta isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x94: { // sty dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_sty(cpu, low, high);
      break;
    }
    case 0x95: { // sta dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x96: { // stx dpy
      uint32_t low = 0;
      uint32_t high = cpu_adrDpy(cpu, &low);
      cpu_stx(cpu, low, high);
      break;
    }
    case 0x97: { // sta ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x98: { // tya imp
      cpu_adrImp(cpu);
      if(cpu->mf) {
        cpu->a = (cpu->a & 0xff00) | (cpu->y & 0xff);
      } else {
        cpu->a = cpu->y;
      }
      cpu_setZN(cpu, cpu->a, cpu->mf);
      break;
    }
    case 0x99: { // sta aby
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, true);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x9a: { // txs imp
      cpu_adrImp(cpu);
      cpu->sp = cpu->x;
      break;
    }
    case 0x9b: { // txy imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->y = cpu->x & 0xff;
      } else {
        cpu->y = cpu->x;
      }
      cpu_setZN(cpu, cpu->y, cpu->xf);
      break;
    }
    case 0x9c: { // stz abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_stz(cpu, low, high);
      break;
    }
    case 0x9d: { // sta abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0x9e: { // stz abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_stz(cpu, low, high);
      break;
    }
    case 0x9f: { // sta alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_sta(cpu, low, high);
      break;
    }
    case 0xa0: { // ldy imm(x)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, true);
      cpu_ldy(cpu, low, high);
      break;
    }
    case 0xa1: { // lda idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xa2: { // ldx imm(x)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, true);
      cpu_ldx(cpu, low, high);
      break;
    }
    case 0xa3: { // lda sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xa4: { // ldy dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_ldy(cpu, low, high);
      break;
    }
    case 0xa5: { // lda dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xa6: { // ldx dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_ldx(cpu, low, high);
      break;
    }
    case 0xa7: { // lda idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xa8: { // tay imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->y = cpu->a & 0xff;
      } else {
        cpu->y = cpu->a;
      }
      cpu_setZN(cpu, cpu->y, cpu->xf);
      break;
    }
    case 0xa9: { // lda imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xaa: { // tax imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->x = cpu->a & 0xff;
      } else {
        cpu->x = cpu->a;
      }
      cpu_setZN(cpu, cpu->x, cpu->xf);
      break;
    }
    case 0xab: { // plb imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu->db = cpu_pullByte(cpu);
      cpu_setZN(cpu, cpu->db, true);
      break;
    }
    case 0xac: { // ldy abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_ldy(cpu, low, high);
      break;
    }
    case 0xad: { // lda abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xae: { // ldx abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_ldx(cpu, low, high);
      break;
    }
    case 0xaf: { // lda abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xb0: { // bcs rel
      cpu_doBranch(cpu, cpu->c);
      break;
    }
    case 0xb1: { // lda idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xb2: { // lda idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xb3: { // lda isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xb4: { // ldy dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_ldy(cpu, low, high);
      break;
    }
    case 0xb5: { // lda dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xb6: { // ldx dpy
      uint32_t low = 0;
      uint32_t high = cpu_adrDpy(cpu, &low);
      cpu_ldx(cpu, low, high);
      break;
    }
    case 0xb7: { // lda ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xb8: { // clv imp
      cpu_adrImp(cpu);
      cpu->v = false;
      break;
    }
    case 0xb9: { // lda aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xba: { // tsx imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->x = cpu->sp & 0xff;
      } else {
        cpu->x = cpu->sp;
      }
      cpu_setZN(cpu, cpu->x, cpu->xf);
      break;
    }
    case 0xbb: { // tyx imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->x = cpu->y & 0xff;
      } else {
        cpu->x = cpu->y;
      }
      cpu_setZN(cpu, cpu->x, cpu->xf);
      break;
    }
    case 0xbc: { // ldy abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_ldy(cpu, low, high);
      break;
    }
    case 0xbd: { // lda abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xbe: { // ldx aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_ldx(cpu, low, high);
      break;
    }
    case 0xbf: { // lda alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_lda(cpu, low, high);
      break;
    }
    case 0xc0: { // cpy imm(x)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, true);
      cpu_cpy(cpu, low, high);
      break;
    }
    case 0xc1: { // cmp idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xc2: { // rep imm(s)
      uint8_t val = cpu_readOpcode(cpu);
      cpu_checkInt(cpu);
      cpu_setFlags(cpu, cpu_getFlags(cpu) & ~val);
      cpu_idle(cpu);
      break;
    }
    case 0xc3: { // cmp sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xc4: { // cpy dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_cpy(cpu, low, high);
      break;
    }
    case 0xc5: { // cmp dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xc6: { // dec dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_dec(cpu, low, high);
      break;
    }
    case 0xc7: { // cmp idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xc8: { // iny imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->y = (cpu->y + 1) & 0xff;
      } else {
        cpu->y++;
      }
      cpu_setZN(cpu, cpu->y, cpu->xf);
      break;
    }
    case 0xc9: { // cmp imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xca: { // dex imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->x = (cpu->x - 1) & 0xff;
      } else {
        cpu->x--;
      }
      cpu_setZN(cpu, cpu->x, cpu->xf);
      break;
    }
    case 0xcb: { // wai imp
      cpu->waiting = true;
      cpu_idle(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0xcc: { // cpy abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_cpy(cpu, low, high);
      break;
    }
    case 0xcd: { // cmp abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xce: { // dec abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_dec(cpu, low, high);
      break;
    }
    case 0xcf: { // cmp abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xd0: { // bne rel
      cpu_doBranch(cpu, !cpu->z);
      break;
    }
    case 0xd1: { // cmp idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xd2: { // cmp idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xd3: { // cmp isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xd4: { // pei dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_pushWord(cpu, cpu_readWord(cpu, low, high, false), true);
      break;
    }
    case 0xd5: { // cmp dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xd6: { // dec dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_dec(cpu, low, high);
      break;
    }
    case 0xd7: { // cmp ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xd8: { // cld imp
      cpu_adrImp(cpu);
      cpu->d = false;
      break;
    }
    case 0xd9: { // cmp aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xda: { // phx imp
      cpu_idle(cpu);
      if(cpu->xf) {
        cpu_checkInt(cpu);
        cpu_pushByte(cpu, cpu->x);
      } else {
        cpu_pushWord(cpu, cpu->x, true);
      }
      break;
    }
    case 0xdb: { // stp imp
      cpu->stopped = true;
      cpu_idle(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0xdc: { // jml ial
      uint16_t adr = cpu_readOpcodeWord(cpu, false);
      cpu->pc = cpu_readWord(cpu, adr, (adr + 1) & 0xffff, false);
      cpu_checkInt(cpu);
      cpu->k = cpu_read(cpu, (adr + 2) & 0xffff);
      break;
    }
    case 0xdd: { // cmp abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xde: { // dec abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_dec(cpu, low, high);
      break;
    }
    case 0xdf: { // cmp alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_cmp(cpu, low, high);
      break;
    }
    case 0xe0: { // cpx imm(x)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, true);
      cpu_cpx(cpu, low, high);
      break;
    }
    case 0xe1: { // sbc idx
      uint32_t low = 0;
      uint32_t high = cpu_adrIdx(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xe2: { // sep imm(s)
      uint8_t val = cpu_readOpcode(cpu);
      cpu_checkInt(cpu);
      cpu_setFlags(cpu, cpu_getFlags(cpu) | val);
      cpu_idle(cpu);
      break;
    }
    case 0xe3: { // sbc sr
      uint32_t low = 0;
      uint32_t high = cpu_adrSr(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xe4: { // cpx dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_cpx(cpu, low, high);
      break;
    }
    case 0xe5: { // sbc dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xe6: { // inc dp
      uint32_t low = 0;
      uint32_t high = cpu_adrDp(cpu, &low);
      cpu_inc(cpu, low, high);
      break;
    }
    case 0xe7: { // sbc idl
      uint32_t low = 0;
      uint32_t high = cpu_adrIdl(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xe8: { // inx imp
      cpu_adrImp(cpu);
      if(cpu->xf) {
        cpu->x = (cpu->x + 1) & 0xff;
      } else {
        cpu->x++;
      }
      cpu_setZN(cpu, cpu->x, cpu->xf);
      break;
    }
    case 0xe9: { // sbc imm(m)
      uint32_t low = 0;
      uint32_t high = cpu_adrImm(cpu, &low, false);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xea: { // nop imp
      cpu_adrImp(cpu);
      // no operation
      break;
    }
    case 0xeb: { // xba imp
      uint8_t low = cpu->a & 0xff;
      uint8_t high = cpu->a >> 8;
      cpu->a = (low << 8) | high;
      cpu_setZN(cpu, high, true);
      cpu_idle(cpu);
      cpu_checkInt(cpu);
      cpu_idle(cpu);
      break;
    }
    case 0xec: { // cpx abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_cpx(cpu, low, high);
      break;
    }
    case 0xed: { // sbc abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xee: { // inc abs
      uint32_t low = 0;
      uint32_t high = cpu_adrAbs(cpu, &low);
      cpu_inc(cpu, low, high);
      break;
    }
    case 0xef: { // sbc abl
      uint32_t low = 0;
      uint32_t high = cpu_adrAbl(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xf0: { // beq rel
      cpu_doBranch(cpu, cpu->z);
      break;
    }
    case 0xf1: { // sbc idy(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrIdy(cpu, &low, false);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xf2: { // sbc idp
      uint32_t low = 0;
      uint32_t high = cpu_adrIdp(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xf3: { // sbc isy
      uint32_t low = 0;
      uint32_t high = cpu_adrIsy(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xf4: { // pea imm(l)
      cpu_pushWord(cpu, cpu_readOpcodeWord(cpu, false), true);
      break;
    }
    case 0xf5: { // sbc dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xf6: { // inc dpx
      uint32_t low = 0;
      uint32_t high = cpu_adrDpx(cpu, &low);
      cpu_inc(cpu, low, high);
      break;
    }
    case 0xf7: { // sbc ily
      uint32_t low = 0;
      uint32_t high = cpu_adrIly(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xf8: { // sed imp
      cpu_adrImp(cpu);
      cpu->d = true;
      break;
    }
    case 0xf9: { // sbc aby(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAby(cpu, &low, false);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xfa: { // plx imp
      cpu_idle(cpu);
      cpu_idle(cpu);
      if(cpu->xf) {
        cpu_checkInt(cpu);
        cpu->x = cpu_pullByte(cpu);
      } else {
        cpu->x = cpu_pullWord(cpu, true);
      }
      cpu_setZN(cpu, cpu->x, cpu->xf);
      break;
    }
    case 0xfb: { // xce imp
      cpu_adrImp(cpu);
      bool temp = cpu->c;
      cpu->c = cpu->e;
      cpu->e = temp;
      cpu_setFlags(cpu, cpu_getFlags(cpu)); // updates x and m flags, clears upper half of x and y if needed
      break;
    }
    case 0xfc: { // jsr iax
      uint8_t adrl = cpu_readOpcode(cpu);
      cpu_pushWord(cpu, cpu->pc, false);
      uint16_t adr = adrl | (cpu_readOpcode(cpu) << 8);
      cpu_idle(cpu);
      uint16_t value = cpu_readWord(cpu, (cpu->k << 16) | ((adr + cpu->x) & 0xffff), (cpu->k << 16) | ((adr + cpu->x + 1) & 0xffff), true);
      cpu->pc = value;
      break;
    }
    case 0xfd: { // sbc abx(r)
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, false);
      cpu_sbc(cpu, low, high);
      break;
    }
    case 0xfe: { // inc abx
      uint32_t low = 0;
      uint32_t high = cpu_adrAbx(cpu, &low, true);
      cpu_inc(cpu, low, high);
      break;
    }
    case 0xff: { // sbc alx
      uint32_t low = 0;
      uint32_t high = cpu_adrAlx(cpu, &low);
      cpu_sbc(cpu, low, high);
      break;
    }
  }
}


// ---------------------------------------------------------------------------
// Static-recompilation entry points (generated wrappers).
// Each cpu_op_XX executes exactly the micro-ops of one 65816 opcode, with the
// opcode decode constant-folded away. The recompiled blocks call these directly.
// ---------------------------------------------------------------------------
void cpu_op_00(Cpu* cpu) { cpu_doOpcode(cpu, 0x00); }
void cpu_op_01(Cpu* cpu) { cpu_doOpcode(cpu, 0x01); }
void cpu_op_02(Cpu* cpu) { cpu_doOpcode(cpu, 0x02); }
void cpu_op_03(Cpu* cpu) { cpu_doOpcode(cpu, 0x03); }
void cpu_op_04(Cpu* cpu) { cpu_doOpcode(cpu, 0x04); }
void cpu_op_05(Cpu* cpu) { cpu_doOpcode(cpu, 0x05); }
void cpu_op_06(Cpu* cpu) { cpu_doOpcode(cpu, 0x06); }
void cpu_op_07(Cpu* cpu) { cpu_doOpcode(cpu, 0x07); }
void cpu_op_08(Cpu* cpu) { cpu_doOpcode(cpu, 0x08); }
void cpu_op_09(Cpu* cpu) { cpu_doOpcode(cpu, 0x09); }
void cpu_op_0A(Cpu* cpu) { cpu_doOpcode(cpu, 0x0A); }
void cpu_op_0B(Cpu* cpu) { cpu_doOpcode(cpu, 0x0B); }
void cpu_op_0C(Cpu* cpu) { cpu_doOpcode(cpu, 0x0C); }
void cpu_op_0D(Cpu* cpu) { cpu_doOpcode(cpu, 0x0D); }
void cpu_op_0E(Cpu* cpu) { cpu_doOpcode(cpu, 0x0E); }
void cpu_op_0F(Cpu* cpu) { cpu_doOpcode(cpu, 0x0F); }
void cpu_op_10(Cpu* cpu) { cpu_doOpcode(cpu, 0x10); }
void cpu_op_11(Cpu* cpu) { cpu_doOpcode(cpu, 0x11); }
void cpu_op_12(Cpu* cpu) { cpu_doOpcode(cpu, 0x12); }
void cpu_op_13(Cpu* cpu) { cpu_doOpcode(cpu, 0x13); }
void cpu_op_14(Cpu* cpu) { cpu_doOpcode(cpu, 0x14); }
void cpu_op_15(Cpu* cpu) { cpu_doOpcode(cpu, 0x15); }
void cpu_op_16(Cpu* cpu) { cpu_doOpcode(cpu, 0x16); }
void cpu_op_17(Cpu* cpu) { cpu_doOpcode(cpu, 0x17); }
void cpu_op_18(Cpu* cpu) { cpu_doOpcode(cpu, 0x18); }
void cpu_op_19(Cpu* cpu) { cpu_doOpcode(cpu, 0x19); }
void cpu_op_1A(Cpu* cpu) { cpu_doOpcode(cpu, 0x1A); }
void cpu_op_1B(Cpu* cpu) { cpu_doOpcode(cpu, 0x1B); }
void cpu_op_1C(Cpu* cpu) { cpu_doOpcode(cpu, 0x1C); }
void cpu_op_1D(Cpu* cpu) { cpu_doOpcode(cpu, 0x1D); }
void cpu_op_1E(Cpu* cpu) { cpu_doOpcode(cpu, 0x1E); }
void cpu_op_1F(Cpu* cpu) { cpu_doOpcode(cpu, 0x1F); }
void cpu_op_20(Cpu* cpu) { cpu_doOpcode(cpu, 0x20); }
void cpu_op_21(Cpu* cpu) { cpu_doOpcode(cpu, 0x21); }
void cpu_op_22(Cpu* cpu) { cpu_doOpcode(cpu, 0x22); }
void cpu_op_23(Cpu* cpu) { cpu_doOpcode(cpu, 0x23); }
void cpu_op_24(Cpu* cpu) { cpu_doOpcode(cpu, 0x24); }
void cpu_op_25(Cpu* cpu) { cpu_doOpcode(cpu, 0x25); }
void cpu_op_26(Cpu* cpu) { cpu_doOpcode(cpu, 0x26); }
void cpu_op_27(Cpu* cpu) { cpu_doOpcode(cpu, 0x27); }
void cpu_op_28(Cpu* cpu) { cpu_doOpcode(cpu, 0x28); }
void cpu_op_29(Cpu* cpu) { cpu_doOpcode(cpu, 0x29); }
void cpu_op_2A(Cpu* cpu) { cpu_doOpcode(cpu, 0x2A); }
void cpu_op_2B(Cpu* cpu) { cpu_doOpcode(cpu, 0x2B); }
void cpu_op_2C(Cpu* cpu) { cpu_doOpcode(cpu, 0x2C); }
void cpu_op_2D(Cpu* cpu) { cpu_doOpcode(cpu, 0x2D); }
void cpu_op_2E(Cpu* cpu) { cpu_doOpcode(cpu, 0x2E); }
void cpu_op_2F(Cpu* cpu) { cpu_doOpcode(cpu, 0x2F); }
void cpu_op_30(Cpu* cpu) { cpu_doOpcode(cpu, 0x30); }
void cpu_op_31(Cpu* cpu) { cpu_doOpcode(cpu, 0x31); }
void cpu_op_32(Cpu* cpu) { cpu_doOpcode(cpu, 0x32); }
void cpu_op_33(Cpu* cpu) { cpu_doOpcode(cpu, 0x33); }
void cpu_op_34(Cpu* cpu) { cpu_doOpcode(cpu, 0x34); }
void cpu_op_35(Cpu* cpu) { cpu_doOpcode(cpu, 0x35); }
void cpu_op_36(Cpu* cpu) { cpu_doOpcode(cpu, 0x36); }
void cpu_op_37(Cpu* cpu) { cpu_doOpcode(cpu, 0x37); }
void cpu_op_38(Cpu* cpu) { cpu_doOpcode(cpu, 0x38); }
void cpu_op_39(Cpu* cpu) { cpu_doOpcode(cpu, 0x39); }
void cpu_op_3A(Cpu* cpu) { cpu_doOpcode(cpu, 0x3A); }
void cpu_op_3B(Cpu* cpu) { cpu_doOpcode(cpu, 0x3B); }
void cpu_op_3C(Cpu* cpu) { cpu_doOpcode(cpu, 0x3C); }
void cpu_op_3D(Cpu* cpu) { cpu_doOpcode(cpu, 0x3D); }
void cpu_op_3E(Cpu* cpu) { cpu_doOpcode(cpu, 0x3E); }
void cpu_op_3F(Cpu* cpu) { cpu_doOpcode(cpu, 0x3F); }
void cpu_op_40(Cpu* cpu) { cpu_doOpcode(cpu, 0x40); }
void cpu_op_41(Cpu* cpu) { cpu_doOpcode(cpu, 0x41); }
void cpu_op_42(Cpu* cpu) { cpu_doOpcode(cpu, 0x42); }
void cpu_op_43(Cpu* cpu) { cpu_doOpcode(cpu, 0x43); }
void cpu_op_44(Cpu* cpu) { cpu_doOpcode(cpu, 0x44); }
void cpu_op_45(Cpu* cpu) { cpu_doOpcode(cpu, 0x45); }
void cpu_op_46(Cpu* cpu) { cpu_doOpcode(cpu, 0x46); }
void cpu_op_47(Cpu* cpu) { cpu_doOpcode(cpu, 0x47); }
void cpu_op_48(Cpu* cpu) { cpu_doOpcode(cpu, 0x48); }
void cpu_op_49(Cpu* cpu) { cpu_doOpcode(cpu, 0x49); }
void cpu_op_4A(Cpu* cpu) { cpu_doOpcode(cpu, 0x4A); }
void cpu_op_4B(Cpu* cpu) { cpu_doOpcode(cpu, 0x4B); }
void cpu_op_4C(Cpu* cpu) { cpu_doOpcode(cpu, 0x4C); }
void cpu_op_4D(Cpu* cpu) { cpu_doOpcode(cpu, 0x4D); }
void cpu_op_4E(Cpu* cpu) { cpu_doOpcode(cpu, 0x4E); }
void cpu_op_4F(Cpu* cpu) { cpu_doOpcode(cpu, 0x4F); }
void cpu_op_50(Cpu* cpu) { cpu_doOpcode(cpu, 0x50); }
void cpu_op_51(Cpu* cpu) { cpu_doOpcode(cpu, 0x51); }
void cpu_op_52(Cpu* cpu) { cpu_doOpcode(cpu, 0x52); }
void cpu_op_53(Cpu* cpu) { cpu_doOpcode(cpu, 0x53); }
void cpu_op_54(Cpu* cpu) { cpu_doOpcode(cpu, 0x54); }
void cpu_op_55(Cpu* cpu) { cpu_doOpcode(cpu, 0x55); }
void cpu_op_56(Cpu* cpu) { cpu_doOpcode(cpu, 0x56); }
void cpu_op_57(Cpu* cpu) { cpu_doOpcode(cpu, 0x57); }
void cpu_op_58(Cpu* cpu) { cpu_doOpcode(cpu, 0x58); }
void cpu_op_59(Cpu* cpu) { cpu_doOpcode(cpu, 0x59); }
void cpu_op_5A(Cpu* cpu) { cpu_doOpcode(cpu, 0x5A); }
void cpu_op_5B(Cpu* cpu) { cpu_doOpcode(cpu, 0x5B); }
void cpu_op_5C(Cpu* cpu) { cpu_doOpcode(cpu, 0x5C); }
void cpu_op_5D(Cpu* cpu) { cpu_doOpcode(cpu, 0x5D); }
void cpu_op_5E(Cpu* cpu) { cpu_doOpcode(cpu, 0x5E); }
void cpu_op_5F(Cpu* cpu) { cpu_doOpcode(cpu, 0x5F); }
void cpu_op_60(Cpu* cpu) { cpu_doOpcode(cpu, 0x60); }
void cpu_op_61(Cpu* cpu) { cpu_doOpcode(cpu, 0x61); }
void cpu_op_62(Cpu* cpu) { cpu_doOpcode(cpu, 0x62); }
void cpu_op_63(Cpu* cpu) { cpu_doOpcode(cpu, 0x63); }
void cpu_op_64(Cpu* cpu) { cpu_doOpcode(cpu, 0x64); }
void cpu_op_65(Cpu* cpu) { cpu_doOpcode(cpu, 0x65); }
void cpu_op_66(Cpu* cpu) { cpu_doOpcode(cpu, 0x66); }
void cpu_op_67(Cpu* cpu) { cpu_doOpcode(cpu, 0x67); }
void cpu_op_68(Cpu* cpu) { cpu_doOpcode(cpu, 0x68); }
void cpu_op_69(Cpu* cpu) { cpu_doOpcode(cpu, 0x69); }
void cpu_op_6A(Cpu* cpu) { cpu_doOpcode(cpu, 0x6A); }
void cpu_op_6B(Cpu* cpu) { cpu_doOpcode(cpu, 0x6B); }
void cpu_op_6C(Cpu* cpu) { cpu_doOpcode(cpu, 0x6C); }
void cpu_op_6D(Cpu* cpu) { cpu_doOpcode(cpu, 0x6D); }
void cpu_op_6E(Cpu* cpu) { cpu_doOpcode(cpu, 0x6E); }
void cpu_op_6F(Cpu* cpu) { cpu_doOpcode(cpu, 0x6F); }
void cpu_op_70(Cpu* cpu) { cpu_doOpcode(cpu, 0x70); }
void cpu_op_71(Cpu* cpu) { cpu_doOpcode(cpu, 0x71); }
void cpu_op_72(Cpu* cpu) { cpu_doOpcode(cpu, 0x72); }
void cpu_op_73(Cpu* cpu) { cpu_doOpcode(cpu, 0x73); }
void cpu_op_74(Cpu* cpu) { cpu_doOpcode(cpu, 0x74); }
void cpu_op_75(Cpu* cpu) { cpu_doOpcode(cpu, 0x75); }
void cpu_op_76(Cpu* cpu) { cpu_doOpcode(cpu, 0x76); }
void cpu_op_77(Cpu* cpu) { cpu_doOpcode(cpu, 0x77); }
void cpu_op_78(Cpu* cpu) { cpu_doOpcode(cpu, 0x78); }
void cpu_op_79(Cpu* cpu) { cpu_doOpcode(cpu, 0x79); }
void cpu_op_7A(Cpu* cpu) { cpu_doOpcode(cpu, 0x7A); }
void cpu_op_7B(Cpu* cpu) { cpu_doOpcode(cpu, 0x7B); }
void cpu_op_7C(Cpu* cpu) { cpu_doOpcode(cpu, 0x7C); }
void cpu_op_7D(Cpu* cpu) { cpu_doOpcode(cpu, 0x7D); }
void cpu_op_7E(Cpu* cpu) { cpu_doOpcode(cpu, 0x7E); }
void cpu_op_7F(Cpu* cpu) { cpu_doOpcode(cpu, 0x7F); }
void cpu_op_80(Cpu* cpu) { cpu_doOpcode(cpu, 0x80); }
void cpu_op_81(Cpu* cpu) { cpu_doOpcode(cpu, 0x81); }
void cpu_op_82(Cpu* cpu) { cpu_doOpcode(cpu, 0x82); }
void cpu_op_83(Cpu* cpu) { cpu_doOpcode(cpu, 0x83); }
void cpu_op_84(Cpu* cpu) { cpu_doOpcode(cpu, 0x84); }
void cpu_op_85(Cpu* cpu) { cpu_doOpcode(cpu, 0x85); }
void cpu_op_86(Cpu* cpu) { cpu_doOpcode(cpu, 0x86); }
void cpu_op_87(Cpu* cpu) { cpu_doOpcode(cpu, 0x87); }
void cpu_op_88(Cpu* cpu) { cpu_doOpcode(cpu, 0x88); }
void cpu_op_89(Cpu* cpu) { cpu_doOpcode(cpu, 0x89); }
void cpu_op_8A(Cpu* cpu) { cpu_doOpcode(cpu, 0x8A); }
void cpu_op_8B(Cpu* cpu) { cpu_doOpcode(cpu, 0x8B); }
void cpu_op_8C(Cpu* cpu) { cpu_doOpcode(cpu, 0x8C); }
void cpu_op_8D(Cpu* cpu) { cpu_doOpcode(cpu, 0x8D); }
void cpu_op_8E(Cpu* cpu) { cpu_doOpcode(cpu, 0x8E); }
void cpu_op_8F(Cpu* cpu) { cpu_doOpcode(cpu, 0x8F); }
void cpu_op_90(Cpu* cpu) { cpu_doOpcode(cpu, 0x90); }
void cpu_op_91(Cpu* cpu) { cpu_doOpcode(cpu, 0x91); }
void cpu_op_92(Cpu* cpu) { cpu_doOpcode(cpu, 0x92); }
void cpu_op_93(Cpu* cpu) { cpu_doOpcode(cpu, 0x93); }
void cpu_op_94(Cpu* cpu) { cpu_doOpcode(cpu, 0x94); }
void cpu_op_95(Cpu* cpu) { cpu_doOpcode(cpu, 0x95); }
void cpu_op_96(Cpu* cpu) { cpu_doOpcode(cpu, 0x96); }
void cpu_op_97(Cpu* cpu) { cpu_doOpcode(cpu, 0x97); }
void cpu_op_98(Cpu* cpu) { cpu_doOpcode(cpu, 0x98); }
void cpu_op_99(Cpu* cpu) { cpu_doOpcode(cpu, 0x99); }
void cpu_op_9A(Cpu* cpu) { cpu_doOpcode(cpu, 0x9A); }
void cpu_op_9B(Cpu* cpu) { cpu_doOpcode(cpu, 0x9B); }
void cpu_op_9C(Cpu* cpu) { cpu_doOpcode(cpu, 0x9C); }
void cpu_op_9D(Cpu* cpu) { cpu_doOpcode(cpu, 0x9D); }
void cpu_op_9E(Cpu* cpu) { cpu_doOpcode(cpu, 0x9E); }
void cpu_op_9F(Cpu* cpu) { cpu_doOpcode(cpu, 0x9F); }
void cpu_op_A0(Cpu* cpu) { cpu_doOpcode(cpu, 0xA0); }
void cpu_op_A1(Cpu* cpu) { cpu_doOpcode(cpu, 0xA1); }
void cpu_op_A2(Cpu* cpu) { cpu_doOpcode(cpu, 0xA2); }
void cpu_op_A3(Cpu* cpu) { cpu_doOpcode(cpu, 0xA3); }
void cpu_op_A4(Cpu* cpu) { cpu_doOpcode(cpu, 0xA4); }
void cpu_op_A5(Cpu* cpu) { cpu_doOpcode(cpu, 0xA5); }
void cpu_op_A6(Cpu* cpu) { cpu_doOpcode(cpu, 0xA6); }
void cpu_op_A7(Cpu* cpu) { cpu_doOpcode(cpu, 0xA7); }
void cpu_op_A8(Cpu* cpu) { cpu_doOpcode(cpu, 0xA8); }
void cpu_op_A9(Cpu* cpu) { cpu_doOpcode(cpu, 0xA9); }
void cpu_op_AA(Cpu* cpu) { cpu_doOpcode(cpu, 0xAA); }
void cpu_op_AB(Cpu* cpu) { cpu_doOpcode(cpu, 0xAB); }
void cpu_op_AC(Cpu* cpu) { cpu_doOpcode(cpu, 0xAC); }
void cpu_op_AD(Cpu* cpu) { cpu_doOpcode(cpu, 0xAD); }
void cpu_op_AE(Cpu* cpu) { cpu_doOpcode(cpu, 0xAE); }
void cpu_op_AF(Cpu* cpu) { cpu_doOpcode(cpu, 0xAF); }
void cpu_op_B0(Cpu* cpu) { cpu_doOpcode(cpu, 0xB0); }
void cpu_op_B1(Cpu* cpu) { cpu_doOpcode(cpu, 0xB1); }
void cpu_op_B2(Cpu* cpu) { cpu_doOpcode(cpu, 0xB2); }
void cpu_op_B3(Cpu* cpu) { cpu_doOpcode(cpu, 0xB3); }
void cpu_op_B4(Cpu* cpu) { cpu_doOpcode(cpu, 0xB4); }
void cpu_op_B5(Cpu* cpu) { cpu_doOpcode(cpu, 0xB5); }
void cpu_op_B6(Cpu* cpu) { cpu_doOpcode(cpu, 0xB6); }
void cpu_op_B7(Cpu* cpu) { cpu_doOpcode(cpu, 0xB7); }
void cpu_op_B8(Cpu* cpu) { cpu_doOpcode(cpu, 0xB8); }
void cpu_op_B9(Cpu* cpu) { cpu_doOpcode(cpu, 0xB9); }
void cpu_op_BA(Cpu* cpu) { cpu_doOpcode(cpu, 0xBA); }
void cpu_op_BB(Cpu* cpu) { cpu_doOpcode(cpu, 0xBB); }
void cpu_op_BC(Cpu* cpu) { cpu_doOpcode(cpu, 0xBC); }
void cpu_op_BD(Cpu* cpu) { cpu_doOpcode(cpu, 0xBD); }
void cpu_op_BE(Cpu* cpu) { cpu_doOpcode(cpu, 0xBE); }
void cpu_op_BF(Cpu* cpu) { cpu_doOpcode(cpu, 0xBF); }
void cpu_op_C0(Cpu* cpu) { cpu_doOpcode(cpu, 0xC0); }
void cpu_op_C1(Cpu* cpu) { cpu_doOpcode(cpu, 0xC1); }
void cpu_op_C2(Cpu* cpu) { cpu_doOpcode(cpu, 0xC2); }
void cpu_op_C3(Cpu* cpu) { cpu_doOpcode(cpu, 0xC3); }
void cpu_op_C4(Cpu* cpu) { cpu_doOpcode(cpu, 0xC4); }
void cpu_op_C5(Cpu* cpu) { cpu_doOpcode(cpu, 0xC5); }
void cpu_op_C6(Cpu* cpu) { cpu_doOpcode(cpu, 0xC6); }
void cpu_op_C7(Cpu* cpu) { cpu_doOpcode(cpu, 0xC7); }
void cpu_op_C8(Cpu* cpu) { cpu_doOpcode(cpu, 0xC8); }
void cpu_op_C9(Cpu* cpu) { cpu_doOpcode(cpu, 0xC9); }
void cpu_op_CA(Cpu* cpu) { cpu_doOpcode(cpu, 0xCA); }
void cpu_op_CB(Cpu* cpu) { cpu_doOpcode(cpu, 0xCB); }
void cpu_op_CC(Cpu* cpu) { cpu_doOpcode(cpu, 0xCC); }
void cpu_op_CD(Cpu* cpu) { cpu_doOpcode(cpu, 0xCD); }
void cpu_op_CE(Cpu* cpu) { cpu_doOpcode(cpu, 0xCE); }
void cpu_op_CF(Cpu* cpu) { cpu_doOpcode(cpu, 0xCF); }
void cpu_op_D0(Cpu* cpu) { cpu_doOpcode(cpu, 0xD0); }
void cpu_op_D1(Cpu* cpu) { cpu_doOpcode(cpu, 0xD1); }
void cpu_op_D2(Cpu* cpu) { cpu_doOpcode(cpu, 0xD2); }
void cpu_op_D3(Cpu* cpu) { cpu_doOpcode(cpu, 0xD3); }
void cpu_op_D4(Cpu* cpu) { cpu_doOpcode(cpu, 0xD4); }
void cpu_op_D5(Cpu* cpu) { cpu_doOpcode(cpu, 0xD5); }
void cpu_op_D6(Cpu* cpu) { cpu_doOpcode(cpu, 0xD6); }
void cpu_op_D7(Cpu* cpu) { cpu_doOpcode(cpu, 0xD7); }
void cpu_op_D8(Cpu* cpu) { cpu_doOpcode(cpu, 0xD8); }
void cpu_op_D9(Cpu* cpu) { cpu_doOpcode(cpu, 0xD9); }
void cpu_op_DA(Cpu* cpu) { cpu_doOpcode(cpu, 0xDA); }
void cpu_op_DB(Cpu* cpu) { cpu_doOpcode(cpu, 0xDB); }
void cpu_op_DC(Cpu* cpu) { cpu_doOpcode(cpu, 0xDC); }
void cpu_op_DD(Cpu* cpu) { cpu_doOpcode(cpu, 0xDD); }
void cpu_op_DE(Cpu* cpu) { cpu_doOpcode(cpu, 0xDE); }
void cpu_op_DF(Cpu* cpu) { cpu_doOpcode(cpu, 0xDF); }
void cpu_op_E0(Cpu* cpu) { cpu_doOpcode(cpu, 0xE0); }
void cpu_op_E1(Cpu* cpu) { cpu_doOpcode(cpu, 0xE1); }
void cpu_op_E2(Cpu* cpu) { cpu_doOpcode(cpu, 0xE2); }
void cpu_op_E3(Cpu* cpu) { cpu_doOpcode(cpu, 0xE3); }
void cpu_op_E4(Cpu* cpu) { cpu_doOpcode(cpu, 0xE4); }
void cpu_op_E5(Cpu* cpu) { cpu_doOpcode(cpu, 0xE5); }
void cpu_op_E6(Cpu* cpu) { cpu_doOpcode(cpu, 0xE6); }
void cpu_op_E7(Cpu* cpu) { cpu_doOpcode(cpu, 0xE7); }
void cpu_op_E8(Cpu* cpu) { cpu_doOpcode(cpu, 0xE8); }
void cpu_op_E9(Cpu* cpu) { cpu_doOpcode(cpu, 0xE9); }
void cpu_op_EA(Cpu* cpu) { cpu_doOpcode(cpu, 0xEA); }
void cpu_op_EB(Cpu* cpu) { cpu_doOpcode(cpu, 0xEB); }
void cpu_op_EC(Cpu* cpu) { cpu_doOpcode(cpu, 0xEC); }
void cpu_op_ED(Cpu* cpu) { cpu_doOpcode(cpu, 0xED); }
void cpu_op_EE(Cpu* cpu) { cpu_doOpcode(cpu, 0xEE); }
void cpu_op_EF(Cpu* cpu) { cpu_doOpcode(cpu, 0xEF); }
void cpu_op_F0(Cpu* cpu) { cpu_doOpcode(cpu, 0xF0); }
void cpu_op_F1(Cpu* cpu) { cpu_doOpcode(cpu, 0xF1); }
void cpu_op_F2(Cpu* cpu) { cpu_doOpcode(cpu, 0xF2); }
void cpu_op_F3(Cpu* cpu) { cpu_doOpcode(cpu, 0xF3); }
void cpu_op_F4(Cpu* cpu) { cpu_doOpcode(cpu, 0xF4); }
void cpu_op_F5(Cpu* cpu) { cpu_doOpcode(cpu, 0xF5); }
void cpu_op_F6(Cpu* cpu) { cpu_doOpcode(cpu, 0xF6); }
void cpu_op_F7(Cpu* cpu) { cpu_doOpcode(cpu, 0xF7); }
void cpu_op_F8(Cpu* cpu) { cpu_doOpcode(cpu, 0xF8); }
void cpu_op_F9(Cpu* cpu) { cpu_doOpcode(cpu, 0xF9); }
void cpu_op_FA(Cpu* cpu) { cpu_doOpcode(cpu, 0xFA); }
void cpu_op_FB(Cpu* cpu) { cpu_doOpcode(cpu, 0xFB); }
void cpu_op_FC(Cpu* cpu) { cpu_doOpcode(cpu, 0xFC); }
void cpu_op_FD(Cpu* cpu) { cpu_doOpcode(cpu, 0xFD); }
void cpu_op_FE(Cpu* cpu) { cpu_doOpcode(cpu, 0xFE); }
void cpu_op_FF(Cpu* cpu) { cpu_doOpcode(cpu, 0xFF); }

void cpu_fetchOpcode(Cpu* cpu) { cpu_readOpcode(cpu); }

#ifdef RECOMP_VERIFY
extern void recomp_verifyHook(Cpu* cpu);
#endif

uint64_t recomp_stat_hit = 0, recomp_stat_miss = 0;

// Runs one recompiled block if one exists for the current (pb:pc, m, x);
// otherwise falls back to the exact interpreter for a single opcode.
void cpu_runBlock(Cpu* cpu) {
  if(cpu->resetWanted || cpu->stopped || cpu->waiting || cpu->intWanted) {
    cpu_runOpcode(cpu);
    return;
  }
  if(recomp_dispatch(cpu)) {
    recomp_stat_hit++;
    return;
  }
  recomp_stat_miss++;
  recomp_logMiss(cpu);
  cpu_runOpcode(cpu);
}
