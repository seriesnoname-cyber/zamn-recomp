#!/bin/bash
# Coverage-guided recompilation loop.
# usage: iterate.sh ROM frames seed1 [seed2 ...]   (seed 0 = fixed script)
cd "$(dirname "$0")/.."
ROM="$1"; FR="$2"; shift 2
rm -f gen/cov_*.txt
python3 tools/recomp.py "$ROM" runtime/cpu.c gen/recomp_blocks.c
round=0
for pass in 1 2 3; do
 for seed in "$@"; do
  round=$((round+1))
  ./tools/build.sh recomp tools/rc_run || exit 1
  INPUT_SEED=$seed RECOMP_COVERAGE=gen/cov_$round.txt ./tools/rc_run "$ROM" $FR /tmp/claude-0/rc.ppm | tail -1
  if [ -f gen/cov_$round.txt ]; then
    python3 tools/recomp.py "$ROM" runtime/cpu.c gen/recomp_blocks.c gen/cov_*.txt
  fi
 done
done
