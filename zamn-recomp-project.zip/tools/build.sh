#!/bin/bash
# usage: build.sh {interp|recomp} out_binary [extra gcc flags]
set -e
cd "$(dirname "$0")/.."
RT=runtime
SRC="$RT/spc.c $RT/dsp.c $RT/apu.c $RT/cpu.c $RT/dma.c $RT/ppu.c $RT/cart.c $RT/input.c $RT/statehandler.c $RT/snes.c $RT/snes_other.c"
MODE=$1; OUT=$2; shift 2
if [ "$MODE" = interp ]; then
  gcc -O2 -w -I$RT "$@" -o $OUT host/headless.c host/recomp_support.c host/recomp_stub.c $SRC -lm
else
  gcc -O1 -w -DRECOMP -I$RT "$@" -o $OUT host/headless.c host/recomp_support.c gen/recomp_blocks.c $SRC -lm
fi
