#!/usr/bin/env python3
"""
SNES 65816 static recompiler (block level).

Reads a LoROM image, traces code from the interrupt vectors (plus any extra
entry points learned from runtime coverage), tracks the M/X/E flag state
statically and emits C: one function per basic block + a dispatch switch.

Every instruction is emitted as   cpu_fetchOpcode(); cpu_op_XX();
where cpu_op_XX is the exact per-opcode micro-op sequence extracted from the
runtime CPU core (bus accesses, cycle counts, open-bus behaviour preserved).
Code the tracer cannot prove (indirect jumps, RAM code, unknown flag state)
is not translated; the runtime falls back to the exact interpreter for it and
logs the miss so the next run of this tool can pick it up.

usage: recomp.py ROM.sfc runtime/cpu.c out.c [coverage.txt ...]
"""
import re, sys

rom_path, cpu_c, out_path = sys.argv[1:4]
cov_paths = sys.argv[4:]
rom = open(rom_path, 'rb').read()
ROM_SIZE = len(rom)

# ---- opcode table, parsed from the runtime core so there is one source of truth
MODE = {}
MNEM = {}
for m in re.finditer(r'case 0x([0-9a-f]{2}): \{ // (\w+) (\S+)', open(cpu_c).read()):
    MNEM[int(m.group(1), 16)] = m.group(2)
    MODE[int(m.group(1), 16)] = m.group(3)
assert len(MODE) == 256, len(MODE)

BASE_LEN = {'imp': 1, 'imm(s)': 2, 'imm(l)': 3, 'rel': 2, 'rll': 3, 'abl': 4, 'alx': 4,
            'abs': 3, 'abx': 3, 'aby': 3, 'abx(r)': 3, 'aby(r)': 3, 'ind': 3, 'iax': 3,
            'ial': 3, 'bm': 3}
for md in ('dp', 'dpx', 'dpy', 'idp', 'idx', 'idy', 'idy(r)', 'idl', 'ily', 'sr', 'isy'):
    BASE_LEN[md] = 2

def length(op, m, x):
    md = MODE[op]
    if md == 'imm(m)':
        return 2 if m else 3
    if md == 'imm(x)':
        return 2 if x else 3
    return BASE_LEN[md]

COND_BR = {'bpl', 'bmi', 'bvc', 'bvs', 'bcc', 'bcs', 'bne', 'beq'}

def rom_offset(bank, adr):
    """Return ROM file offset for a LoROM address, or None if not ROM-backed."""
    if bank in (0x7e, 0x7f):
        return None
    if adr < 0x8000 and (bank & 0x7f) < 0x40:
        return None
    b = bank & 0x7f
    return ((b << 15) | (adr & 0x7fff)) & (ROM_SIZE - 1)

def fetch(bank, adr, n):
    out = []
    for i in range(n):
        off = rom_offset(bank, (adr + i) & 0xffff)  # instruction cannot cross bank (pc wraps)
        if off is None:
            return None
        out.append(rom[off])
    return out

# ---- tracing -----------------------------------------------------------------

class Insn:
    __slots__ = ('addr', 'op', 'n', 'm', 'x')

def decode_block(bank, adr, m, x, e, stop_at=None):
    """Linear decode from (bank:adr) until a terminator.
       Returns (insns, successors, ended_by_unknown_state)."""
    insns = []
    succ = []
    prev_clc = prev_sec = False
    while True:
        if stop_at is not None and insns and (bank, adr, m, x) in stop_at:
            return insns, [], False          # falls through into another block
        n = length_probe = None
        b0 = fetch(bank, adr, 1)
        if b0 is None:
            return insns, succ, True
        op = b0[0]
        n = length(op, m, x)
        raw = fetch(bank, adr, n)
        if raw is None:
            return insns, succ, True
        i = Insn(); i.addr = adr; i.op = op; i.n = n; i.m = m; i.x = x
        insns.append(i)
        mn = MNEM[op]
        nxt = (adr + n) & 0xffff
        was_clc, was_sec = prev_clc, prev_sec
        prev_clc = (mn == 'clc'); prev_sec = (mn == 'sec')

        if mn in ('rep', 'sep') and not e:
            if mn == 'rep':
                m = m and not (raw[1] & 0x20); x = x and not (raw[1] & 0x10)
            else:
                m = m or bool(raw[1] & 0x20); x = x or bool(raw[1] & 0x10)
            m, x = int(m), int(x)
        elif mn == 'xce':
            if was_clc:
                e = False
            elif was_sec:
                e = True; m = x = 1
            else:
                return insns, succ, True
        elif mn in ('plp', 'rti'):
            return insns, succ, True
        elif mn in COND_BR:
            t = (nxt + (raw[1] - 256 if raw[1] > 127 else raw[1])) & 0xffff
            succ += [(bank, t, m, x, e), (bank, nxt, m, x, e)]
            return insns, succ, False
        elif mn == 'bra':
            succ.append((bank, (nxt + (raw[1] - 256 if raw[1] > 127 else raw[1])) & 0xffff, m, x, e))
            return insns, succ, False
        elif mn == 'brl':
            d = raw[1] | (raw[2] << 8)
            succ.append((bank, (nxt + d) & 0xffff, m, x, e))
            return insns, succ, False
        elif mn == 'jmp' and MODE[op] == 'abs':
            succ.append((bank, raw[1] | (raw[2] << 8), m, x, e))
            return insns, succ, False
        elif mn == 'jml' and MODE[op] == 'abl':
            succ.append((raw[3], raw[1] | (raw[2] << 8), m, x, e))
            return insns, succ, False
        elif mn == 'jsr' and MODE[op] == 'abs':
            succ += [(bank, raw[1] | (raw[2] << 8), m, x, e), (bank, nxt, m, x, e)]
            return insns, succ, False
        elif mn == 'jsl':
            succ += [(raw[3], raw[1] | (raw[2] << 8), m, x, e), (bank, nxt, m, x, e)]
            return insns, succ, False
        elif mn in ('jsr', 'jmp', 'jml'):    # indirect forms
            if mn == 'jsr':
                succ.append((bank, nxt, m, x, e))
            return insns, succ, False
        elif MODE[op] == 'bm':       # MVN/MVP repeat by rewinding pc: dynamic control flow
            succ += [(bank, adr, m, x, e), (bank, nxt, m, x, e)]
            return insns, succ, False
        elif mn in ('rts', 'rtl'):
            return insns, succ, False
        elif mn in ('wai', 'brk', 'cop'):
            succ.append((bank, nxt if mn == 'wai' else (nxt) & 0xffff, m, x, e))
            return insns, succ, False
        elif mn == 'stp':
            return insns, succ, False
        adr = nxt

def vec(a):
    off = rom_offset(0, a)
    return rom[off] | (rom[off + 1] << 8)

def trace_all():
    seeds = []
    for v in (0xfffc, 0xffea, 0xffee, 0xffe4, 0xffe6):   # reset nmi irq cop brk
        a = vec(v)
        # reset: e=1 => m=x=1; interrupts taken in native mode keep flags unknown, try both common states
        seeds.append((0, a, 1, 1, True))
        if v != 0xfffc:
            for (m, x) in ((1, 1), (1, 0), (0, 0), (0, 1)):
                seeds.append((0, a, m, x, False))
    # extra entries learned at runtime
    for p in cov_paths:
        try:
            for line in open(p):
                line = line.strip()
                if not line:
                    continue
                a, m, x = line.split()
                bank, adr = a.split(':')
                seeds.append((int(bank, 16), int(adr, 16), int(m), int(x), False))
        except FileNotFoundError:
            pass
    entries = {}
    work = list(seeds)
    while work:
        bank, adr, m, x, e = work.pop()
        key = (bank, adr, m, x)
        if key in entries:
            continue
        if rom_offset(bank, adr) is None:
            continue
        insns, succ, _ = decode_block(bank, adr, m, x, e)
        entries[key] = e
        work.extend(succ)
    return entries

# ---- emission ----------------------------------------------------------------

def emit(entries):
    keys = set(entries)
    blocks = []
    n_insn = 0
    for key in sorted(keys):
        bank, adr, m, x = key
        insns, _, _ = decode_block(bank, adr, m, x, entries[key], stop_at=keys)
        if not insns:
            continue
        blocks.append((key, insns))
        n_insn += len(insns)

    L = []
    L.append('// GENERATED by tools/recomp.py -- do not edit.')
    L.append('#include <stdint.h>')
    L.append('#include <stdio.h>')
    L.append('#include <stdlib.h>')
    L.append('#include "cpu.h"')
    L.append('#ifdef RECOMP_VERIFY')
    L.append('extern void recomp_verifyHook(Cpu* cpu);')
    L.append('#define VH recomp_verifyHook(cpu);')
    L.append('#else')
    L.append('#define VH')
    L.append('#endif')
    L.append('#define I(op)  cpu_fetchOpcode(cpu); cpu_op_##op(cpu); VH if(cpu->intWanted) return;')
    L.append('#define IL(op) cpu_fetchOpcode(cpu); cpu_op_##op(cpu); VH')
    L.append('')
    for key, insns in blocks:
        bank, adr, m, x = key
        L.append(f'static void b_{bank:02x}_{adr:04x}_{m}{x}(Cpu* cpu) {{')
        body = []
        for idx, i in enumerate(insns):
            macro = 'IL' if idx == len(insns) - 1 else 'I'
            body.append(f'{macro}({i.op:02X})')
        # keep lines short & readable: 8 instructions per line
        for k in range(0, len(body), 8):
            L.append('  ' + ' '.join(body[k:k + 8]))
        L.append('}')
    L.append('')
    L.append('int recomp_dispatch(Cpu* cpu) {')
    L.append('  uint32_t key = ((((uint32_t) cpu->k << 16) | cpu->pc) << 2) | ((uint32_t) cpu->mf << 1) | (uint32_t) cpu->xf;')
    L.append('  switch(key) {')
    for key, insns in blocks:
        bank, adr, m, x = key
        k = (((bank << 16) | adr) << 2) | (m << 1) | x
        L.append(f'    case 0x{k:x}u: b_{bank:02x}_{adr:04x}_{m}{x}(cpu); return 1;')
    L.append('    default: return 0;')
    L.append('  }')
    L.append('}')
    L.append('')
    L.append(f'const int recomp_blockCount = {len(blocks)};')
    L.append(f'const int recomp_insnCount = {n_insn};')
    return '\n'.join(L) + '\n', len(blocks), n_insn

entries = trace_all()
code, nb, ni = emit(entries)
open(out_path, 'w').write(code)
print(f'{nb} blocks, {ni} instructions -> {out_path}')
